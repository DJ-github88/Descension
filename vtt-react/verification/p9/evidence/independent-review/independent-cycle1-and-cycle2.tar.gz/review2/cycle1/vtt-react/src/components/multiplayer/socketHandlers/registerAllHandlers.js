import { registerConnectionHandlers } from './connectionHandlers';
import { registerRoomLifecycleHandlers } from './roomLifecycleHandlers';
import { registerChatHandlers } from './chatHandlers';
import { registerPartyHandlers } from './partyHandlers';
import { registerTokenHandlers } from './tokenHandlers';
import { registerCharacterHandlers } from './characterHandlers';
import { registerCombatHandlers } from './combatHandlers';
import { registerConditionHandlers } from './conditionHandlers';
import { registerMapGridHandlers } from './mapGridHandlers';
import { registerQuestHandlers } from './questHandlers';
import { registerGmHandlers } from './gmHandlers';
import { registerJournalHandlers } from './journalHandlers';
import { registerInventoryHandlers } from './inventoryHandlers';
import { registerAudioGameSessionHandlers } from './audioGameSessionHandlers';
import { registerErrorHandlers } from './errorHandlers';
import { isSocketRetired } from '../../../persistence/handoff/socketPrincipalRetirement';
import { registerActorHandlers } from '../../../services/actorConsequenceService';
import { registerSpellConsequenceHandlers } from '../../../services/spellConsequenceService';

export function registerAllSocketHandlers(ctx) {
  // Wave A (P5/S4): never register handlers on a retired principal's socket.
  // Its late events must be dropped, not rebound to new state.
  if (!ctx || isSocketRetired(ctx.socket)) {
    return () => {};
  }

  const cleanupFns = [
    registerActorHandlers(ctx),
    registerSpellConsequenceHandlers(ctx),
    registerConnectionHandlers(ctx),
    registerRoomLifecycleHandlers(ctx),
    registerChatHandlers(ctx),
    registerPartyHandlers(ctx),
    registerTokenHandlers(ctx),
    registerCharacterHandlers(ctx),
    registerCombatHandlers(ctx),
    registerConditionHandlers(ctx),
    registerMapGridHandlers(ctx),
    registerQuestHandlers(ctx),
    registerGmHandlers(ctx),
    registerJournalHandlers(ctx),
    registerInventoryHandlers(ctx),
    registerAudioGameSessionHandlers(ctx),
    registerErrorHandlers(ctx)
  ];

  return () => {
    cleanupFns.forEach(fn => {
      if (typeof fn === 'function') fn();
    });
  };
}
