import React, { useState, useRef, useEffect, useMemo } from 'react';
import ReactDOM from 'react-dom';
import useChatStore from '../../../../store/chatStore';
import useGameStore from '../../../../store/gameStore';
import useCharacterStore from '../../../../store/characterStore';
import '../styles/ArcanoneerResourceBar.css';
import { useResourceBarTooltip } from '../../../../components/hud/useResourceBarTooltip';
import ClassTip from '../../../../components/hud/ClassTip';
import SpellTooltip from '../../../../components/spellcrafting-wizard/components/common/SpellTooltip';
import { formulationToSpell } from '../formulationToSpell';
import { migrateBlockId } from '../../../../utils/arcanoneerMigration';
import SpellCastConfirmation from '../../../../components/ui/SpellCastConfirmation';
import { routeSpellCast, isP9Routed } from '../../../../services/spellConsequenceService';
import { ARCANONEER_BANK_MAX, ARCANONEER_ROLL_COUNT, normalizeSphereBank } from '../../../classResourceBanks';

import { INK, PAGE, PAPER, RULE, ETCH, inked, washed } from '../../../../components/hud/calmBarPalette';
/**
 * Single source of truth for canonical elements with rich Arcanoneer styling
 */
const CANONICAL_ELEMENTS = [
    { id: 'arcane', name: 'Arcane', abbrev: 'ARC', color: '#9370DB', lightColor: '#d8b4fe', d8Value: 1, theme: 'Raw Magic', summary: 'Arcane damage, kinetic disorientation', flavor: 'The shape behind all other shapes, raw kinetic intent.' },
    { id: 'sacred', name: 'Sacred', abbrev: 'SAC', color: '#eab308', lightColor: '#fef08a', d8Value: 2, theme: 'Divine Light', summary: 'Sacred damage, blinding, protection, cleansing', flavor: 'The first clause of the First Contract: let there be sight.' },
    { id: 'blight', name: 'Blight', abbrev: 'BLI', color: '#8b5cf6', lightColor: '#c084fc', d8Value: 3, theme: 'Darkness', summary: 'Blight damage, curses, entropic decay', flavor: 'The silence after the clause, what the light leaves behind.' },
    { id: 'ember', name: 'Ember', abbrev: 'EMB', color: '#ea580c', lightColor: '#fdba74', d8Value: 4, theme: 'Flames', summary: 'Ember damage, ignition, combustion', flavor: 'The first tool humanity mastered, captured in a crystal shard.' },
    { id: 'rime', name: 'Rime', abbrev: 'RIM', color: '#0284c7', lightColor: '#7dd3fc', d8Value: 5, theme: 'Rime', summary: 'Rime damage, slowing, brittle', flavor: 'Entropy deferred, motion held still in crystal lattice.' },
    { id: 'primal', name: 'Primal', abbrev: 'PRI', color: '#16a34a', lightColor: '#86efac', d8Value: 6, theme: 'Growth', summary: 'Primal damage, grasping vines, poison (condition)', flavor: 'The green arc between seed and sky.' },
    { id: 'storm', name: 'Storm', abbrev: 'STO', color: '#0891b2', lightColor: '#67e8f9', d8Value: 7, theme: 'Storm', summary: 'Storm damage, stunning, chain resonance', flavor: 'The sky\'s voice captured in crystal, raw current and sound.' },
    { id: 'wyrd', name: 'Wyrd', abbrev: 'WYR', color: '#db2777', lightColor: '#f472b6', d8Value: 8, theme: 'Unpredictability', summary: 'Wyrd damage, chaotic variable effects', flavor: 'The clause Morvane will not interpret.', isGradient: true }
];

/**
 * ArcanoneerResourceBar: "The Calibrated Iron Sleeve"
 *
 * Magi-Ballistic Focus Cylinder in pure SVG & CSS.
 * - Sized cleanly for the Party HUD without stretching the card (74px height).
 * - Forged Gunmetal and Guild Brass apparatus with mechanical rivets & pressure gauge.
 * - 8 Themed Elemental Chambers with radiant 3D crystal orbs, glyphs, and brass pips.
 * - Kinetic Ignition Primer ("ROLL 4d8") with mechanical tumbler spin.
 * - Non-scrolling Matrix Explorer modal: select an element to instantly view its 8 combinations.
 */
const ArcanoneerResourceBar = ({
    classResource = {},
    size = 'normal',
    config = {},
    context = 'hud',
    isOwner = true,
    onClassResourceUpdate = null,
    showcase = false,
}) => {
    // ===== Configuration =====
    const blocks = (config?.elements && config.elements.length > 0) ? config.elements : CANONICAL_ELEMENTS;
    const maxBank = ARCANONEER_BANK_MAX;
    const matrix = config?.combinationMatrix || null;
    const matrixEntries = matrix?.entries || [];

    const canEdit = isOwner;

    // ===== State =====
    const normalizeSpheres = normalizeSphereBank;
    const [localSpheres, setLocalSpheres] = useState(normalizeSpheres(classResource?.spheres));
    const spheresRef = useRef(localSpheres);
    const rollTimerRef = useRef(null);
    const [isRolling, setIsRolling] = useState(false);
    const [hoveredBlockId, setHoveredBlockId] = useState(null);
    const [showBarTooltip, setShowBarTooltip] = useState(false);
    const [showMatrixModal, setShowMatrixModal] = useState(false);
    const [lastRollResult, setLastRollResult] = useState(null);

    // Matrix search/picker state: null = all ready or prompt, elementId = filter by element
    const [selectedElementA, setSelectedElementA] = useState(null);
    const [selectedElementB, setSelectedElementB] = useState(null);

    // Spell Cast Confirmation Modal state
    const [spellToCast, setSpellToCast] = useState(null);

    // Formulation spellcard hover
    const [hoveredFormulation, setHoveredFormulation] = useState(null);
    const formHoverTimeoutRef = useRef(null);
    const formHideTimeoutRef = useRef(null);

    // Keep localSpheres in sync if upstream changes
    useEffect(() => {
        const incoming = normalizeSpheres(classResource?.spheres);
        spheresRef.current = incoming;
        if (incoming.length !== localSpheres.length || incoming.some((v, i) => v !== localSpheres[i])) {
            setLocalSpheres(incoming);
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [classResource?.spheres]);

    useEffect(() => () => clearTimeout(rollTimerRef.current), []);

    const barRef = useRef(null);
    const matrixModalRef = useRef(null);

    // Shared tooltip hook for element and bar hovering
    const tooltipRef = useResourceBarTooltip(
        barRef,
        (hoveredBlockId !== null || showBarTooltip) && !showMatrixModal,
        [hoveredBlockId, showBarTooltip, showMatrixModal, localSpheres],
        {
            preferredWidth: 320,
            preferredHeight: 240,
        }
    );

    // Close Matrix Modal on outside click
    useEffect(() => {
        if (!showMatrixModal) return;
        const onDown = (e) => {
            const inModal = matrixModalRef.current && matrixModalRef.current.contains(e.target);
            const inBar = barRef.current && barRef.current.contains(e.target);
            if (!inModal && !inBar) {
                setShowMatrixModal(false);
            }
        };
        const id = setTimeout(() => document.addEventListener('mousedown', onDown), 0);
        return () => {
            clearTimeout(id);
            document.removeEventListener('mousedown', onDown);
        };
    }, [showMatrixModal]);

    // Stores & Combat Logging
    const { addCombatNotification } = useChatStore();
    const isGMMode = useGameStore(state => state.isGMMode);
    const currentPlayerName = useCharacterStore(state => state.name || 'Player');

    const getActorName = () => {
        const actorName = currentPlayerName || 'Player';
        return isGMMode ? `${actorName} (GM)` : actorName;
    };

    const logChange = (blockName, amount, isPositive) => {
        const absAmount = Math.abs(amount);
        if (absAmount === 0) return;
        const actorName = getActorName();
        const characterName = currentPlayerName || 'Character';
        const verb = isPositive ? 'chambered' : 'expelled';
        addCombatNotification({
            type: 'combat_resource',
            attacker: actorName,
            target: characterName,
            amount: absAmount,
            resourceType: 'classResource',
            isPositive,
            customMessage: `${characterName} ${verb} ${absAmount} ${blockName} sphere${absAmount === 1 ? '' : 's'}`
        });
    };

    // Derived values
    const blockCounts = useMemo(() => {
        const counts = {};
        for (const b of blocks) counts[b.id] = 0;
        for (const id of localSpheres) {
            if (counts[id] !== undefined) counts[id] += 1;
        }
        return counts;
    }, [localSpheres, blocks]);

    const totalBanked = localSpheres.length;

    // Ready formulations
    const readyFormulations = useMemo(() => {
        const out = [];
        for (const entry of matrixEntries) {
            const [a, b] = entry.elements;
            const need = (a === b) ? 2 : 1;
            if ((blockCounts[a] || 0) >= need && (blockCounts[b] || 0) >= need) {
                out.push(entry);
            }
        }
        return out;
    }, [matrixEntries, blockCounts]);

    const readyCount = readyFormulations.length;

    // Filtered formulations for the Matrix Explorer (NO SCROLLING)
    const filteredFormulations = useMemo(() => {
        if (selectedElementA && selectedElementB) {
            // Target exact pair
            return matrixEntries.filter(entry => {
                const [a, b] = entry.elements;
                return (a === selectedElementA && b === selectedElementB) || (a === selectedElementB && b === selectedElementA);
            });
        }
        if (selectedElementA) {
            // Target all 8 combinations involving selectedElementA
            return matrixEntries.filter(entry => entry.elements.includes(selectedElementA));
        }
        // Default when nothing selected: show ready formulations (if any), otherwise pure pairs (8 items)
        if (readyFormulations.length > 0) {
            return readyFormulations.slice(0, 8);
        }
        // Pure pairs (exactly 8 items, fits cleanly in 2x4 grid without scrolling)
        return matrixEntries.filter(entry => entry.elements[0] === entry.elements[1]);
    }, [matrixEntries, selectedElementA, selectedElementB, readyFormulations]);

    // Actions
    const commitSpheres = (next, changeLog = null) => {
        const capped = normalizeSphereBank(next);
        spheresRef.current = capped;
        setLocalSpheres(capped);
        if (onClassResourceUpdate) onClassResourceUpdate('spheres', capped);
        if (changeLog) logChange(changeLog.name, changeLog.amount, changeLog.isPositive);
    };

    const addBlock = (blockId) => {
        if (!canEdit) return;
        if (totalBanked >= maxBank) return;
        const blockName = blocks.find(b => b.id === blockId)?.name || 'Sphere';
        commitSpheres([...localSpheres, blockId], { name: blockName, amount: 1, isPositive: true });
    };

    const removeBlock = (blockId) => {
        if (!canEdit) return;
        const idx = localSpheres.lastIndexOf(blockId);
        if (idx < 0) return;
        const next = [...localSpheres];
        next.splice(idx, 1);
        const blockName = blocks.find(b => b.id === blockId)?.name || 'Sphere';
        commitSpheres(next, { name: blockName, amount: 1, isPositive: false });
    };

    const clearAll = () => {
        if (!canEdit || totalBanked === 0) return;
        const cleared = [...localSpheres];
        commitSpheres([], { name: 'all spheres', amount: cleared.length, isPositive: false });
    };

    const roll4d8 = (e) => {
        if (e) e.stopPropagation();
        if (!canEdit || isRolling || totalBanked >= maxBank) return;
        setIsRolling(true);
        setLastRollResult(null);

        const dice = [];
        const newBlocks = [];
        for (let i = 0; i < ARCANONEER_ROLL_COUNT; i++) {
            const roll = Math.floor(Math.random() * 8) + 1;
            dice.push(roll);
            const block = blocks.find(b => b.d8Value === roll);
            if (block) newBlocks.push(block.id);
        }
        setLastRollResult({ dice, blocks: newBlocks });

        rollTimerRef.current = setTimeout(() => {
            const currentBank = spheresRef.current;
            const next = [...currentBank, ...newBlocks].slice(0, maxBank);
            const banked = next.length - currentBank.length;
            commitSpheres(next, { name: 'Spheres (4d8)', amount: Math.max(0, banked), isPositive: true });
            setIsRolling(false);
        }, 480);
    };

    const getBlock = (id) => blocks.find(b => b.id === id);
    const formulationsUsingBlock = (blockId) => matrixEntries.filter(e => e.elements.includes(blockId));

    // ===== Spell Casting Confirmation Handlers =====
    const handleInitiateCast = (entry) => {
        if (!entry) return;
        const spell = formulationToSpell(entry, matrix);
        // P9: formulation cards are presentation transforms with no original class
        // definition, so they stay manual; any supported original routes to P9.
        if (spell && !showcase && routeSpellCast(spell, { producer: 'arcanoneer' })) return;
        if (spell) {
            setSpellToCast(spell);
        }
    };

    const handleSpellCastConfirm = () => {
        if (!spellToCast) return;
        if (!showcase && isP9Routed(spellToCast)) { setSpellToCast(null); return; }

        // 1. Extract resource costs
        const resourceCost = spellToCast.resourceCost || {};
        const resourceValues = resourceCost.resourceValues || {};
        const manaCost = resourceValues.mana || resourceCost.mana || 0;
        const apCost = resourceCost.actionPoints || 0;

        // Extract required elemental spheres
        const requiredSpheres = [];
        if (Array.isArray(spellToCast._arcanoneerElements)) {
            spellToCast._arcanoneerElements.forEach(el => requiredSpheres.push(migrateBlockId(el)));
        } else if (Array.isArray(spellToCast.elements)) {
            spellToCast.elements.forEach(el => requiredSpheres.push(migrateBlockId(el)));
        } else if (Array.isArray(resourceCost.spheres)) {
            resourceCost.spheres.forEach(el => requiredSpheres.push(migrateBlockId(el)));
        } else if (resourceValues) {
            Object.entries(resourceValues).forEach(([key, val]) => {
                if (key.endsWith('_sphere')) {
                    const elem = migrateBlockId(key.replace('_sphere', ''));
                    const cnt = Number(val) || 0;
                    for (let i = 0; i < cnt; i++) requiredSpheres.push(elem);
                }
            });
        }

        // 2. Validate availability
        const charStore = useCharacterStore.getState();
        const currentMana = charStore.mana;
        const currentAP = charStore.actionPoints;

        if (!showcase && manaCost > 0 && (!currentMana || currentMana.current < manaCost)) return;
        if (!showcase && apCost > 0 && (!currentAP || currentAP.current < apCost)) return;

        const sphereBankCopy = [...localSpheres];
        for (const req of requiredSpheres) {
            const idx = sphereBankCopy.indexOf(req);
            if (idx === -1) return; // Insufficient spheres
            sphereBankCopy.splice(idx, 1);
        }

        // 3. Deduct Mana
        if (!showcase && manaCost > 0 && currentMana) {
            const newMana = Math.max(0, currentMana.current - manaCost);
            charStore.updateResource('mana', newMana);
            try {
                const usePartyStore = require('../../../../store/partyStore').default;
                const currentMember = usePartyStore.getState().partyMembers.find(m => m.id === 'current-player');
                if (currentMember) {
                    usePartyStore.getState().updatePartyMember('current-player', {
                        character: {
                            ...currentMember.character,
                            mana: { current: newMana, max: currentMana.max }
                        }
                    });
                }
            } catch (err) {}
        }

        // 4. Deduct AP
        if (!showcase && apCost > 0 && currentAP) {
            const newAP = Math.max(0, currentAP.current - apCost);
            charStore.updateResource('actionPoints', newAP);
            try {
                const usePartyStore = require('../../../../store/partyStore').default;
                const currentMember = usePartyStore.getState().partyMembers.find(m => m.id === 'current-player');
                if (currentMember) {
                    usePartyStore.getState().updatePartyMember('current-player', {
                        character: {
                            ...currentMember.character,
                            actionPoints: { current: newAP, max: currentAP.max }
                        }
                    });
                }
            } catch (err) {}
        }

        // 5. Retract / Deduct Spheres
        commitSpheres(sphereBankCopy);
        if (!showcase && !onClassResourceUpdate) charStore.updateClassResource?.('spheres', sphereBankCopy);

        try {
            const usePartyStore = require('../../../../store/partyStore').default;
            const currentMember = usePartyStore.getState().partyMembers.find(m => m.id === 'current-player');
            if (!showcase && currentMember && currentMember.character?.classResource) {
                usePartyStore.getState().updatePartyMember('current-player', {
                    character: {
                        ...currentMember.character,
                        classResource: {
                            ...currentMember.character.classResource,
                            spheres: sphereBankCopy
                        }
                    }
                });
            }
        } catch (err) {}

        // 6. Combat Log Notification
        const actorName = getActorName();
        const characterName = currentPlayerName || 'Character';
        const sphereNames = requiredSpheres.map(s => blocks.find(b => b.id === s)?.name || s).join(' + ');
        addCombatNotification({
            type: 'spell_cast',
            attacker: actorName,
            target: characterName,
            spellName: spellToCast.name,
            customMessage: `${characterName} unleashed weave [${spellToCast.name}] (${sphereNames})! Consumed ${manaCost} Mana, ${apCost} AP, and chambered spheres.`
        });

        // 7. Multiplayer Emit
        const gameStore = useGameStore.getState();
        if (gameStore.isInMultiplayer && gameStore.multiplayerSocket?.connected) {
            gameStore.multiplayerSocket.emit('spell_cast', {
                spellId: spellToCast.id,
                spellName: spellToCast.name,
                casterId: charStore.currentCharacterId || charStore.id,
                targetIds: [],
                targetPositions: [],
                effects: spellToCast.effects || [],
                damage: spellToCast.damage || 0,
                healing: spellToCast.healing || 0,
                timestamp: Date.now()
            });
        }

        // 8. Close popup
        setSpellToCast(null);
    };

    const handleSpellCastCancel = () => {
        setSpellToCast(null);
    };

    // Formulation Hover Handlers
    const handleFormHoverEnter = (entry) => {
        if (formHideTimeoutRef.current) { clearTimeout(formHideTimeoutRef.current); formHideTimeoutRef.current = null; }
        if (formHoverTimeoutRef.current) clearTimeout(formHoverTimeoutRef.current);
        formHoverTimeoutRef.current = setTimeout(() => {
            setHoveredFormulation(entry);
        }, 200);
    };
    const handleFormHoverLeave = () => {
        if (formHoverTimeoutRef.current) clearTimeout(formHoverTimeoutRef.current);
        formHideTimeoutRef.current = setTimeout(() => setHoveredFormulation(null), 100);
    };
    const handleFormTooltipEnter = () => {
        if (formHideTimeoutRef.current) { clearTimeout(formHideTimeoutRef.current); formHideTimeoutRef.current = null; }
    };
    const handleFormTooltipLeave = () => {
        formHideTimeoutRef.current = setTimeout(() => setHoveredFormulation(null), 100);
    };

    const renderFormulationTooltip = () => {
        if (!hoveredFormulation) return null;
        const spell = formulationToSpell(hoveredFormulation, matrix);
        if (!spell) return null;
        return (
            <SpellTooltip
                spell={spell}
                fullscreenMode
                onMouseEnter={handleFormTooltipEnter}
                onMouseLeave={handleFormTooltipLeave}
            />
        );
    };

    // Element / Bar Hover Tooltip
    const renderHoverTooltip = () => {
        if (showMatrixModal) return null;
        if (!hoveredBlockId && !showBarTooltip) return null;

        if (hoveredBlockId) {
            const block = getBlock(hoveredBlockId);
            if (!block) return null;
            const count = blockCounts[block.id] || 0;
            const forms = formulationsUsingBlock(block.id);
            const readyForms = forms.filter(f => {
                const [a, b] = f.elements;
                const need = a === b ? 2 : 1;
                return (blockCounts[a] || 0) >= need && (blockCounts[b] || 0) >= need;
            });

            return ReactDOM.createPortal(
                <div ref={tooltipRef} className="unified-resourcebar-tooltip pathfinder-tooltip arcanoneer-tooltip" style={{ position: 'fixed', left: 0, top: 0, opacity: 0, pointerEvents: 'none', zIndex: 100000 }}>
                    <ClassTip
                        icon="fas fa-gem"
                        tint={block.isGradient ? '#FF00FF' : block.color}
                        title={`${block.name} · d8 face ${block.d8Value}`}
                        subtitle="Arcanoneer Elemental Sphere"
                        state={`${count} banked`}
                        stateTone={count > 0 ? 'good' : 'neutral'}
                        mechanic={`${block.theme} — ${block.summary}`}
                        status={[
                            count > 0
                                ? `${count} chambered in the iron sleeve.`
                                : 'Chamber empty — roll 4d8 to draw elemental spheres.',
                            readyForms.length > 0
                                ? `Ready combinations: ${readyForms.map(f => f.name).join(', ')}.`
                                : forms.length > 0
                                    ? `No ready weave — needs a partner sphere (${forms.length} formulations use this).`
                                    : null,
                        ]}
                        usage={canEdit ? 'Click to chamber (+1) · Right-click to expel (-1)' : null}
                        hint={block.flavor}
                    />
                </div>,
                document.body
            );
        }

        // Bar-level hover
        const readyFormsCount = readyFormulations.length;
        return ReactDOM.createPortal(
            <div ref={tooltipRef} className="unified-resourcebar-tooltip pathfinder-tooltip arcanoneer-tooltip" style={{ position: 'fixed', left: 0, top: 0, opacity: 0, pointerEvents: 'none', zIndex: 100000 }}>
                <ClassTip
                    icon="fas fa-flask"
                    tint="#9370DB"
                    title="Calibrated Iron Sleeve"
                    subtitle="Arcanoneer Formulation Matrix & Spheres"
                    state={`${totalBanked} / ${maxBank} Banked`}
                    stateTone={totalBanked >= maxBank ? 'warn' : totalBanked > 0 ? 'good' : 'neutral'}
                    mechanic="Roll 4d8 each turn; each die banks a sphere (max 12, overflow lost). Combine 2 spheres + mana into a formulation. Offensive weaves pin your movement to 0; Defend doesn't."
                    status={[
                        `Cylinder: ${totalBanked}/${maxBank} spheres chambered.`,
                        readyFormsCount > 0
                            ? `Ready formulations: ${readyFormsCount} spell(s) primed for casting.`
                            : 'No formulations primed — draw or chamber matching sphere pairs.',
                        `${Math.max(0, maxBank - totalBanked)} chamber space left before overflow is lost.`
                    ]}
                    usage="Roll 4d8 to draw spheres · Click chamber (+1) / Right-click (-1) · Click MATRIX to craft"
                    hint="Arcanoneers synthesize arcane artillery by binding twin spheres into destructive or tactical formulations."
                />
            </div>,
            document.body
        );
    };

    // Vector elemental glyph paths centered at (cx, cy)
    const renderElementalGlyph = (id, cx, cy, isFilled) => {
        const strokeColor = isFilled ? INK : inked('#fbbf24', 0.6);
        const fillColor = isFilled ? PAGE : 'none';

        switch (id) {
            case 'arcane':
                return (
                    <g pointerEvents="none">
                        <polygon
                            points={`${cx},${cy - 6.5} ${cx + 2},${cy - 2} ${cx + 6.5},${cy} ${cx + 2},${cy + 2} ${cx},${cy + 6.5} ${cx - 2},${cy + 2} ${cx - 6.5},${cy} ${cx - 2},${cy - 2}`}
                            fill={fillColor}
                            stroke={strokeColor}
                            strokeWidth="0.75"
                        />
                        <circle cx={cx} cy={cy} r="1.3" fill={isFilled ? PAPER : washed('#fde047', 0.2)} />
                    </g>
                );
            case 'sacred':
                return (
                    <g pointerEvents="none">
                        <circle cx={cx} cy={cy} r="3.2" fill={fillColor} stroke={strokeColor} strokeWidth="0.75" />
                        <line x1={cx} y1={cy - 5.5} x2={cx} y2={cy - 4} stroke={strokeColor} strokeWidth="0.75" />
                        <line x1={cx} y1={cy + 4} x2={cx} y2={cy + 5.5} stroke={strokeColor} strokeWidth="0.75" />
                        <line x1={cx - 5.5} y1={cy} x2={cx - 4} y2={cy} stroke={strokeColor} strokeWidth="0.75" />
                        <line x1={cx + 4} y1={cy} x2={cx + 5.5} y2={cy} stroke={strokeColor} strokeWidth="0.75" />
                    </g>
                );
            case 'blight':
                return (
                    <g pointerEvents="none">
                        <path
                            d={`M ${cx - 3.8} ${cy - 3.5} C ${cx - 3.8} ${cy - 6}, ${cx + 3.8} ${cy - 6}, ${cx + 3.8} ${cy - 3.5} C ${cx + 3.8} ${cy - 1}, ${cx + 2.5} ${cy + 2.5}, ${cx + 1.5} ${cy + 4} L ${cx - 1.5} ${cy + 4} C ${cx - 2.5} ${cy + 2.5}, ${cx - 3.8} ${cy - 1}, ${cx - 3.8} ${cy - 3.5} Z`}
                            fill={fillColor}
                            stroke={strokeColor}
                            strokeWidth="0.75"
                        />
                        <circle cx={cx - 1.5} cy={cy - 2.5} r="0.8" fill={isFilled ? PAPER : washed('#fde047', 0.2)} />
                        <circle cx={cx + 1.5} cy={cy - 2.5} r="0.8" fill={isFilled ? PAPER : washed('#fde047', 0.2)} />
                    </g>
                );
            case 'ember':
                return (
                    <g pointerEvents="none">
                        <path
                            d={`M ${cx} ${cy - 6.5} C ${cx + 3} ${cy - 3}, ${cx + 4.5} ${cy + 1}, ${cx + 3.5} ${cy + 4} C ${cx + 2.5} ${cy + 6.5}, ${cx - 2.5} ${cy + 6.5}, ${cx - 3.5} ${cy + 4} C ${cx - 4.5} ${cy + 1}, ${cx - 1.5} ${cy - 2.5}, ${cx} ${cy - 6.5} Z`}
                            fill={fillColor}
                            stroke={strokeColor}
                            strokeWidth="0.75"
                        />
                        <path
                            d={`M ${cx} ${cy - 2} C ${cx + 1.5} ${cy}, ${cx + 1.5} ${cy + 3}, ${cx} ${cy + 4} C ${cx - 1.5} ${cy + 3}, ${cx - 1.5} ${cy}, ${cx} ${cy - 2} Z`}
                            fill={isFilled ? washed('#fef08a', 0.2) : 'none'}
                        />
                    </g>
                );
            case 'rime':
                return (
                    <g pointerEvents="none">
                        <line x1={cx} y1={cy - 5.5} x2={cx} y2={cy + 5.5} stroke={strokeColor} strokeWidth="0.85" />
                        <line x1={cx - 4.8} y1={cy - 2.8} x2={cx + 4.8} y2={cy + 2.8} stroke={strokeColor} strokeWidth="0.85" />
                        <line x1={cx - 4.8} y1={cy + 2.8} x2={cx + 4.8} y2={cy - 2.8} stroke={strokeColor} strokeWidth="0.85" />
                        <circle cx={cx} cy={cy} r="1.3" fill={PAGE} />
                    </g>
                );
            case 'primal':
                return (
                    <g pointerEvents="none">
                        <path
                            d={`M ${cx - 4} ${cy + 4} C ${cx - 5} ${cy}, ${cx - 2.5} ${cy - 5}, ${cx + 4} ${cy - 5} C ${cx + 5} ${cy}, ${cx + 2.5} ${cy + 5}, ${cx - 4} ${cy + 4} Z`}
                            fill={fillColor}
                            stroke={strokeColor}
                            strokeWidth="0.75"
                        />
                        <line x1={cx - 2} y1={cy + 2} x2={cx + 2} y2={cy - 2} stroke={isFilled ? RULE : inked('#fde047', 0.6)} strokeWidth="0.6" />
                    </g>
                );
            case 'storm':
                return (
                    <g pointerEvents="none">
                        <polygon
                            points={`${cx + 1},${cy - 6.5} ${cx - 4},${cy} ${cx},${cy} ${cx - 1.5},${cy + 6.5} ${cx + 5},${cy - 0.5} ${cx + 1},${cy - 0.5}`}
                            fill={fillColor}
                            stroke={strokeColor}
                            strokeWidth="0.75"
                        />
                    </g>
                );
            case 'wyrd':
            default:
                return (
                    <g pointerEvents="none">
                        <polygon
                            points={`${cx},${cy - 5.5} ${cx + 4},${cy - 3.8} ${cx + 5.5},${cy} ${cx + 4},${cy + 3.8} ${cx},${cy + 5.5} ${cx - 4},${cy + 3.8} ${cx - 5.5},${cy} ${cx - 4},${cy - 3.8}`}
                            fill={isFilled ? PAGE : 'none'}
                            stroke={strokeColor}
                            strokeWidth="0.75"
                        />
                        <circle cx={cx} cy={cy} r="1.1" fill={isFilled ? washed('#ec4899', 0.2) : washed('#fde047', 0.2)} />
                    </g>
                );
        }
    };

    // ========================================================================
    // MATRIX EXPLORER MODAL (ZERO SCROLLING, ELEMENT-PICKER TARGETING)
    // ========================================================================
    const handleElementSelect = (elemId) => {
        if (!selectedElementA) {
            setSelectedElementA(elemId);
            setSelectedElementB(null);
        } else if (selectedElementA === elemId && !selectedElementB) {
            // Deselect
            setSelectedElementA(null);
            setSelectedElementB(null);
        } else if (!selectedElementB) {
            setSelectedElementB(elemId);
        } else if (selectedElementB === elemId) {
            setSelectedElementB(null);
        } else {
            // Replace second
            setSelectedElementB(elemId);
        }
    };

    const handleClearFilter = () => {
        setSelectedElementA(null);
        setSelectedElementB(null);
    };

    const renderMatrixModal = () => {
        if (!showMatrixModal || !barRef.current) return null;
        const barRect = barRef.current.getBoundingClientRect();
        const modalWidth = 310;
        let left = barRect.left + (barRect.width / 2) - (modalWidth / 2);
        if (left < 8) left = 8;
        if (left + modalWidth > window.innerWidth - 8) left = window.innerWidth - modalWidth - 8;

        const spaceBelow = window.innerHeight - barRect.bottom;
        const top = spaceBelow > 230 ? barRect.bottom + 4 : Math.max(8, barRect.top - 225);

        const isPairSelected = selectedElementA && selectedElementB;
        const singleSelection = selectedElementA && !selectedElementB;
        const blockA = selectedElementA ? getBlock(selectedElementA) : null;
        const blockB = selectedElementB ? getBlock(selectedElementB) : null;

        return ReactDOM.createPortal(
            <div
                ref={matrixModalRef}
                className="arc-matrix-popup-frame arcanoneer-menu-container class-resource-menu"
                onMouseDown={(e) => { e.stopPropagation(); if (e.nativeEvent?.stopImmediatePropagation) e.nativeEvent.stopImmediatePropagation(); }}
                onClick={(e) => { e.stopPropagation(); if (e.nativeEvent?.stopImmediatePropagation) e.nativeEvent.stopImmediatePropagation(); }}
                onMouseEnter={(e) => { e.stopPropagation(); setShowBarTooltip(false); setHoveredBlockId(null); }}
                onMouseMove={(e) => e.stopPropagation()}
                onMouseOver={(e) => e.stopPropagation()}
                style={{ position: 'fixed', top: `${top}px`, left: `${left}px`, width: `${modalWidth}px`, zIndex: 100000 }}
            >
                {/* Header Strip */}
                <div className="arc-matrix-header-bar">
                    <div className="arc-matrix-title-badge">
                        <i className="fas fa-gear" />
                        <span>COMBINATION MATRIX</span>
                    </div>
                    <div className="arc-matrix-header-status">
                        <span className="arc-matrix-banked-text">Bank: {totalBanked}/12</span>
                        {readyCount > 0 && <span className="arc-matrix-ready-pill">{readyCount} Ready</span>}
                    </div>
                    <button className="arc-matrix-close-btn" onClick={(e) => { e.stopPropagation(); setShowMatrixModal(false); }}>
                        ✕
                    </button>
                </div>

                {/* Element Picker Bar: 8 Clickable Orbs */}
                <div className="arc-matrix-picker-strip">
                    {blocks.map(block => {
                        const isSelected = selectedElementA === block.id || selectedElementB === block.id;
                        const count = blockCounts[block.id] || 0;
                        return (
                            <button
                                key={block.id}
                                className={`arc-matrix-picker-orb ${isSelected ? 'selected' : ''} ${count > 0 ? 'banked' : ''}`}
                                onClick={(e) => { e.stopPropagation(); handleElementSelect(block.id); }}
                                title={`${block.name} (d8=${block.d8Value}): ${count} banked. Click to filter formulas.`}
                                style={{
                                    '--elem-color': block.color,
                                    '--elem-light': block.lightColor
                                }}
                            >
                                <span className="arc-picker-glyph">{block.name.slice(0, 3)}</span>
                                {count > 0 && <span className="arc-picker-dot" />}
                            </button>
                        );
                    })}
                    {(selectedElementA || selectedElementB) && (
                        <button className="arc-matrix-reset-btn" onClick={handleClearFilter} title="Reset element filters">
                            Clear
                        </button>
                    )}
                </div>

                {/* Sub-Banner / Prompt */}
                <div className="arc-matrix-filter-banner">
                    {isPairSelected ? (
                        <div className="arc-filter-banner-text">
                            Targeting: <strong style={{ color: blockA?.color }}>{blockA?.name}</strong> + <strong style={{ color: blockB?.color }}>{blockB?.name}</strong>
                        </div>
                    ) : singleSelection ? (
                        <div className="arc-filter-banner-text">
                            Showing all 8 formulas using <strong style={{ color: blockA?.color }}>{blockA?.name}</strong>. Pick another to isolate:
                        </div>
                    ) : (
                        <div className="arc-filter-banner-text">
                            {readyCount > 0
                                ? `Showing ${Math.min(8, readyCount)} Ready Formulas. Pick an element above to inspect:`
                                : 'Select an element above to inspect its 8 formulas:'}
                        </div>
                    )}
                </div>

                {/* Body Content Area — Strictly NO SCROLL (Max 8 cards) */}
                <div className="arc-matrix-cards-deck">
                    {isPairSelected && filteredFormulations.length > 0 ? (
                        // Exact Spotlight Card
                        (() => {
                            const entry = filteredFormulations[0];
                            const [a, b] = entry.elements;
                            const need = a === b ? 2 : 1;
                            const isReady = (blockCounts[a] || 0) >= need && (blockCounts[b] || 0) >= need;
                            return (
                                <div
                                    className={`arc-spotlight-card ${isReady ? 'ready' : 'unready'}`}
                                    onMouseEnter={() => handleFormHoverEnter(entry)}
                                    onMouseLeave={handleFormHoverLeave}
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        handleInitiateCast(entry);
                                    }}
                                    title="Click to cast weave or inspect costs"
                                >
                                    <div className="arc-spotlight-header">
                                        <span className="arc-spotlight-title">{entry.name}</span>
                                        <span className={`arc-spotlight-status ${isReady ? 'ready' : 'unready'}`}>
                                            {isReady ? '✓ READY TO CAST' : `✗ NEEDS ${need}x SPHERES`}
                                        </span>
                                    </div>
                                    <div className="arc-spotlight-desc">{entry.effectDescription || entry.summary || 'Concentrated elemental burst.'}</div>
                                    <div className="arc-spotlight-meta">
                                        <span>Range: {entry.range || 60}ft</span>
                                        <span>Target: {entry.targetType || 'single'}</span>
                                        <button
                                            className={`arc-spotlight-cast-btn ${isReady ? 'ready' : 'unready'}`}
                                            onClick={(e) => {
                                                e.stopPropagation();
                                                handleInitiateCast(entry);
                                            }}
                                            title={isReady ? `Cast ${entry.name}` : `Inspect costs for ${entry.name}`}
                                        >
                                            <i className="fas fa-bolt" /> {isReady ? 'CAST WEAVE' : 'INSPECT'}
                                        </button>
                                        <span className="arc-spotlight-formula">
                                            {blockA?.name} + {blockB?.name}
                                        </span>
                                    </div>
                                </div>
                            );
                        })()
                    ) : (
                        // Grid of up to 8 cards (2 columns x 4 rows, exact fit, zero scroll)
                        <div className="arc-matrix-grid-8">
                            {filteredFormulations.slice(0, 8).map(entry => {
                                const [a, b] = entry.elements;
                                const need = a === b ? 2 : 1;
                                const isReady = (blockCounts[a] || 0) >= need && (blockCounts[b] || 0) >= need;
                                const bA = getBlock(a);
                                const bB = getBlock(b);

                                return (
                                    <div
                                        key={entry.id}
                                        className={`arc-grid-card ${isReady ? 'ready' : 'unready'}`}
                                        onMouseEnter={() => handleFormHoverEnter(entry)}
                                        onMouseLeave={handleFormHoverLeave}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            // Clicking an item targets its exact pair and prompts cast confirmation
                                            setSelectedElementA(a);
                                            setSelectedElementB(b);
                                            handleInitiateCast(entry);
                                        }}
                                        title={`${entry.name}\n${bA?.name} + ${bB?.name}\nClick to cast · Hover for spellcard`}
                                    >
                                        <div className="arc-grid-card-pair">
                                            <span style={{ color: bA?.color }}>{bA?.abbrev || bA?.name?.slice(0, 3)}</span>
                                            <span className="plus">+</span>
                                            <span style={{ color: bB?.color }}>{bB?.abbrev || bB?.name?.slice(0, 3)}</span>
                                        </div>
                                        <div className="arc-grid-card-name">{entry.name}</div>
                                        {isReady && <span className="arc-grid-ready-icon" title="Ready to cast">⚡</span>}
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>

                {/* Footer Controls */}
                <div className="arc-matrix-footer">
                    {canEdit && totalBanked > 0 && (
                        <button className="arc-matrix-vent-action" onClick={(e) => { e.stopPropagation(); clearAll(); }}>
                            <i className="fas fa-wind" /> Vent Chamber ({totalBanked})
                        </button>
                    )}
                    <span className="arc-matrix-footer-hint">Hover formulas for full spellcards</span>
                </div>
            </div>,
            document.body
        );
    };

    // ========================================================================
    // MASTER SVG RENDER: THE CALIBRATED IRON SLEEVE
    // ========================================================================
    return (
        <div className={`class-resource-bar arcanoneer-blocks ${size} ${context}-context ${showcase ? 'showcase-mode' : ''}`}>
            <div
                className="arc-apparatus-wrapper"
                ref={barRef}
                onMouseEnter={() => setShowBarTooltip(true)}
                onMouseLeave={() => setShowBarTooltip(false)}
            >

                <svg
                    className="arc-master-svg"
                    viewBox="0 0 286 74"
                    xmlns="http://www.w3.org/2000/svg"
                    role="img"
                    aria-label={`Arcanoneer Calibrated Iron Sleeve. Spheres banked: ${totalBanked} of ${maxBank}.`}
                >
                    <defs />

                    {/* Outer Forged Iron Plate */}
                    <rect
                        x="1.5"
                        y="1.5"
                        width="283"
                        height="71"
                        rx="5"
                        fill={PAPER}
                        stroke={inked('#b45309', 0.6)}
                        strokeWidth="1.2"
                        className="arc-iron-casing"
                    />

                    {/* Inner Calibration Inset Bevel */}
                    <rect
                        x="3.5"
                        y="3.5"
                        width="279"
                        height="67"
                        rx="3.5"
                        fill="none"
                        stroke={ETCH}
                        strokeWidth="0.6"
                        pointerEvents="none"
                    />

                    {/* Heavy Mechanical Corner Screws */}
                    <circle cx="5.5" cy="5.5" r="1.3" fill={PAPER} stroke={inked('#fde047', 0.6)} strokeWidth="0.4" pointerEvents="none" />
                    <circle cx="280.5" cy="5.5" r="1.3" fill={PAPER} stroke={inked('#fde047', 0.6)} strokeWidth="0.4" pointerEvents="none" />
                    <circle cx="5.5" cy="68.5" r="1.3" fill={PAPER} stroke={inked('#fde047', 0.6)} strokeWidth="0.4" pointerEvents="none" />
                    <circle cx="280.5" cy="68.5" r="1.3" fill={PAPER} stroke={inked('#fde047', 0.6)} strokeWidth="0.4" pointerEvents="none" />

                    {/* ========================================================= */}
                    {/* TOP MECHANICAL MANTLE                                     */}
                    {/* ========================================================= */}

                    {/* LEFT: Chamber Capacity Pressure Gauge */}
                    <g className="arc-gauge-plate" pointerEvents="none">
                        <rect x="7" y="4.5" width="74" height="17" rx="3" fill={PAPER} stroke={inked('#d97706', 0.6)} strokeWidth="0.75" />
                        <text x="12" y="16.5" className="arc-gauge-title">CHAMBER</text>
                        <text x="75" y="16.5" textAnchor="end" className="arc-gauge-reading">{totalBanked}/{maxBank}</text>
                        {/* 12 Pressure Segment Cells */}
                        <g>
                            {Array.from({ length: 12 }).map((_, seg) => {
                                const sx = 11 + seg * 5.6;
                                const isFilled = seg < totalBanked;
                                return (
                                    <rect
                                        key={seg}
                                        x={sx}
                                        y="18.5"
                                        width="4.5"
                                        height="1.5"
                                        rx="0.5"
                                        fill={isFilled ? (totalBanked >= maxBank ? washed('#ef4444', 0.2) : washed('#f59e0b', 0.2)) : PAGE}
                                    />
                                );
                            })}
                        </g>
                    </g>

                    {/* CENTER: Kinetic Ignition Primer ("ROLL 4d8") */}
                    <g
                        className={`arc-primer-trigger ${isRolling ? 'rolling' : ''} ${totalBanked >= maxBank ? 'bank-full' : ''}`}
                        onClick={roll4d8}
                        style={{ cursor: canEdit && !isRolling && totalBanked < maxBank ? 'pointer' : 'default' }}
                    >
                        <rect
                            x="87"
                            y="4"
                            width="112"
                            height="18"
                            rx="4"
                            fill={PAPER}
                            stroke={inked('#f97316', 0.6)}
                            strokeWidth="1"
                            className="arc-primer-button"
                        />
                        {/* Knurled grip ticks on primer button sides */}
                        <line x1="89" y1="8" x2="89" y2="18" stroke={inked('#fef08a', 0.6)} strokeWidth="0.8" pointerEvents="none" />
                        <line x1="197" y1="8" x2="197" y2="18" stroke={inked('#fef08a', 0.6)} strokeWidth="0.8" pointerEvents="none" />

                        {/* Kinetic d8 Octahedron Die Icon */}
                        <polygon
                            points="96,7 101,10 101,16 96,19 91,16 91,10"
                            fill={washed('#fef08a', 0.2)}
                            stroke={inked('#fef08a', 0.6)}
                            strokeWidth="0.85"
                            className={`arc-d8-tumbler ${isRolling ? 'tumbling' : ''}`}
                        />
                        <text x="106" y="16.5" className="arc-primer-label">
                            {isRolling ? 'PRIMING…' : (lastRollResult ? `🎲 ${lastRollResult.dice.join('·')}` : 'ROLL 4d8')}
                        </text>
                    </g>

                    {/* RIGHT: Matrix Registry Key (Opens Portal Modal) */}
                    <g
                        className={`arc-matrix-trigger ${showMatrixModal ? 'active' : ''} ${readyCount > 0 ? 'has-ready' : ''}`}
                        onClick={(e) => { e.stopPropagation(); setShowMatrixModal(!showMatrixModal); }}
                        style={{ cursor: 'pointer' }}
                    >
                        <rect
                            x="205"
                            y="4.5"
                            width="74"
                            height="17"
                            rx="3"
                            fill={washed('#312e81', 0.2)}
                            stroke={readyCount > 0 ? inked('#4ade80', 0.6) : inked('#d97706', 0.6)}
                            strokeWidth="0.85"
                            className="arc-matrix-key"
                        />
                        {/* Codex / Matrix Dial Icon */}
                        <path
                            d="M 211 8.5 L 215 7.5 L 215 15.5 L 211 16.5 Z M 215 7.5 L 219 8.5 L 219 16.5 L 215 15.5 Z"
                            fill="none"
                            stroke={readyCount > 0 ? inked('#86efac', 0.6) : inked('#fef08a', 0.6)}
                            strokeWidth="0.75"
                            pointerEvents="none"
                        />
                        <text x="223" y="16.5" className="arc-matrix-label" pointerEvents="none">
                            {readyCount > 0 ? `MATRIX (${readyCount})` : 'MATRIX'}
                        </text>
                    </g>

                    {/* ========================================================= */}
                    {/* 8 THEMED ELEMENTAL SPHERES (CYLINDER CHAMBERS)            */}
                    {/* ========================================================= */}
                    {blocks.map((block, i) => {
                        const cx = 21 + i * 34.8;
                        const cy = 44;
                        const count = blockCounts[block.id] || 0;
                        const isFilled = count > 0;
                        const isHovered = hoveredBlockId === block.id;

                        return (
                            <g
                                key={block.id}
                                className={`arc-orb-cell ${isFilled ? 'filled' : 'dormant'} ${isHovered ? 'hovered' : ''}`}
                                onMouseEnter={() => setHoveredBlockId(block.id)}
                                onMouseLeave={() => setHoveredBlockId(null)}
                                onClick={(e) => { e.stopPropagation(); addBlock(block.id); }}
                                onContextMenu={(e) => {
                                    e.preventDefault();
                                    e.stopPropagation();
                                    removeBlock(block.id);
                                }}
                            >
                                {/* Transparent Hitbox */}
                                <rect x={cx - 16} y="24" width="32" height="46" fill="transparent" pointerEvents="all" />

                                {/* Heavy Brass Socket Bezel Housing */}
                                <circle
                                    cx={cx}
                                    cy={cy}
                                    r="13"
                                    fill={PAPER}
                                    stroke={isHovered ? inked('#fef08a', 0.6) : (isFilled ? inked(block.color, 0.55) : inked('#d97706', 0.6))}
                                    strokeWidth={isHovered || isFilled ? '1.1' : '0.6'}
                                    className="arc-socket-bezel"
                                    pointerEvents="none"
                                />

                                {/* Subtle Mechanical Gear/Rivet Teeth on Socket Bezel */}
                                <circle cx={cx - 12} cy={cy} r="0.6" fill={washed('#fbbf24', 0.2)} pointerEvents="none" />
                                <circle cx={cx + 12} cy={cy} r="0.6" fill={washed('#fbbf24', 0.2)} pointerEvents="none" />

                                {/* Dormant Chamber Shadow (when empty) */}
                                {!isFilled && (
                                    <circle cx={cx} cy={cy} r="11.5" fill={PAPER} pointerEvents="none" />
                                )}

                                {/* Searing 3D Glowing Elemental Orb (when banked) */}
                                {isFilled && (
                                    <g pointerEvents="none">
                                        <circle
                                            cx={cx}
                                            cy={cy}
                                            r="11.5"
                                            fill={block.id === 'wyrd' ? washed('#a855f7', 0.2) : `url(#arcSphere_${block.id})`}
                                            className="arc-sphere-body"
                                        />
                                        {/* Specular White Glass Sheen */}
                                        <ellipse cx={cx - 3.5} cy={cy - 4.5} rx="4" ry="2.5" fill={PAGE} />
                                    </g>
                                )}

                                {/* Vector Elemental Glyph inside sphere */}
                                {renderElementalGlyph(block.id, cx, cy, isFilled)}

                                {/* Engraved Brass Pip Coin (Top-Right of Bezel) */}
                                {isFilled && (
                                    <g pointerEvents="none">
                                        <circle cx={cx + 9} cy={cy - 8} r="4.5" fill={PAPER} stroke={inked('#fde047', 0.6)} strokeWidth="0.75" />
                                        <text x={cx + 9} y={cy - 6} textAnchor="middle" className="arc-pip-count-badge">
                                            {count}
                                        </text>
                                    </g>
                                )}

                                {/* Micro Charge Dots (1-5 Pips at base of socket) */}
                                <g pointerEvents="none">
                                    {Array.from({ length: 5 }).map((_, p) => {
                                        const px = cx - 6 + p * 3;
                                        const on = p < count;
                                        return (
                                            <circle
                                                key={p}
                                                cx={px}
                                                cy="61.5"
                                                r="0.9"
                                                fill={on ? (block.isGradient ? washed('#f43f5e', 0.2) : washed(block.color, 0.2)) : PAGE}
                                            />
                                        );
                                    })}
                                </g>

                                {/* Bottom Stamped Serial Plate */}
                                <text x={cx} y="69.5" textAnchor="middle" className="arc-serial-stamp" pointerEvents="none">
                                    {block.name.slice(0, 3).toUpperCase()}·{block.d8Value}
                                </text>
                            </g>
                        );
                    })}
                </svg>

            </div>

            {/* Matrix Explorer Modal (Portal - Zero Scrolling) */}
            {renderMatrixModal()}

            {/* Element Hover Tooltip (Portal) */}
            {renderHoverTooltip()}

            {/* Spellcard Hover Tooltip for Formulations (Portal) */}
            {renderFormulationTooltip()}

            {/* Spell Cast Confirmation Dialog (Portal) */}
            {spellToCast && (
                <SpellCastConfirmation
                    spell={spellToCast}
                    classResource={{ ...classResource, type: 'elementalSpheres', spheres: localSpheres }}
                    onConfirm={handleSpellCastConfirm}
                    onCancel={handleSpellCastCancel}
                />
            )}
        </div>
    );
};

export default ArcanoneerResourceBar;
