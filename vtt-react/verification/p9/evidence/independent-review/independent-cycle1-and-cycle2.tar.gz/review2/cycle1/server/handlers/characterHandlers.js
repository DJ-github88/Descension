/**
 * Character Management Handlers
 *
 * Per-player character state synchronization (resources, equipment, movement):
 * - character_moved: relay position updates (also updates player's currentMapId)
 * - character_resource_delta: apply incremental resource changes (health/mana/AP)
 * - character_updated: full character data sync (including GM character sync)
 * - character_equipment_updated: equipment changes broadcast
 * - character_resource_updated: full resource state sync (health/mana/AP/classResource)
 *   (resolves target player via playerId, senderSocketId, or GM fallback)
 * - buff_update / debuff_update: per-token buff/debuff state relay + persistence
 */

const roomAccess = require('../services/roomAccessService');
const tokenAuthority = require('./tokenHandlers');

function registerCharacterHandlers(ctx) {
  const {
    io,
    socket,
    rooms,
    logger,
    validateRoomMembership,
    firebaseBatchWriter
  } = ctx;

  socket.on('character_moved', async(data) => {
    try {
      const validation = validateRoomMembership(socket, data.roomId);
      if (!validation.valid) {return;}

      const { room, player } = validation;
      const uid = socket.data && socket.data.userId ? socket.data.userId : null;
      const mapId = data.mapId || room.gameState.defaultMapId || 'default';

      // A supplied foreign tokenId is never movable by an ordinary member.
      if (data.tokenId) {
        const maps = room.gameState && room.gameState.maps ? room.gameState.maps : {};
        let record = null;
        let recordMapId = mapId;
        const ownMap = maps[mapId];
        if (ownMap && ownMap.characterTokens && ownMap.characterTokens[data.tokenId]) {
          record = ownMap.characterTokens[data.tokenId];
        } else {
          for (const [candidateMapId, candidateMap] of Object.entries(maps)) {
            if (candidateMap && candidateMap.characterTokens && candidateMap.characterTokens[data.tokenId]) {
              record = candidateMap.characterTokens[data.tokenId];
              recordMapId = candidateMapId;
              break;
            }
          }
        }
        // Only an existing token is authority-checked. Unknown token ids keep
        // the documented legacy relay (clients reconcile by tokenId).
        if (record) {
          const authority = tokenAuthority.resolveTokenAuthority(room, player, data.tokenId, record, recordMapId, uid);
          if (authority === 'none') {
            logger.warn('[character_moved] Unauthorized character token movement blocked', {
              tokenId: data.tokenId, playerId: player.id
            });
            return;
          }
        }
      }

      // Update player's current map if changed
      if (data.mapId && data.mapId !== player.currentMapId) {
        player.currentMapId = data.mapId;
        if (room.gameState.playerMapAssignments) {
          room.gameState.playerMapAssignments[player.id] = data.mapId;
        }
      }

      socket.to(room.id).emit('character_moved', {
        playerId: player.id,
        characterId: data.characterId || player.id,
        tokenId: data.tokenId,
        position: data.position,
        mapId,
        ...(data.actionId ? { actionId: data.actionId } : {}),
        timestamp: Date.now()
      });

    } catch (error) {
      logger.error('[character_moved] Error:', { error: error.message });
    }
  });

  socket.on('character_resource_delta', async(data) => {
    try {
      const validation = validateRoomMembership(socket, data.roomId);
      if (!validation.valid) {return;}

      const { room, player } = validation;

      if (data.resource === 'health' && player.character?.health) {
        player.character.health.current = Math.max(0, Math.min(
          player.character.health.max,
          (player.character.health.current || 0) + (data.delta || 0)
        ));
      } else if (data.resource === 'mana' && player.character?.mana) {
        player.character.mana.current = Math.max(0, Math.min(
          player.character.mana.max,
          (player.character.mana.current || 0) + (data.delta || 0)
        ));
      } else if (data.resource === 'actionPoints' && player.character?.actionPoints) {
        player.character.actionPoints.current = Math.max(0, Math.min(
          player.character.actionPoints.max,
          (player.character.actionPoints.current || 0) + (data.delta || 0)
        ));
      }

      io.to(data.roomId).emit('character_resource_delta', {
        playerId: player.id,
        resource: data.resource,
        delta: data.delta,
        timestamp: Date.now()
      });

      if (room.isPermanent) {
        firebaseBatchWriter.queueWrite(room.id, room.gameState);
      }

    } catch (error) {
      logger.error('[character_resource_delta] Error:', { error: error.message });
    }
  });

  socket.on('character_updated', async(data, ackCallback) => {
    logger.debug('character_updated received', {
      socketId: socket.id,
      characterId: data.characterId,
      hasCharacter: !!data.character
    });
    try {
      const validation = validateRoomMembership(socket, data.roomId);
      if (!validation.valid) {
        logger.warn('character_updated validation failed:', { error: validation.error });
        return;
      }

      const { room, player } = validation;
      logger.debug('character_updated validated', { playerId: player.id, roomId: room.id });

      const actors = require('../services/actorConsequences');
      actors.validateBuildEnvelope('character_updated', data);
      const updates = data.character ? { character: data.character } : {};
      const blocked = actors.protectedPath(data, 0, actors.buildPaths('character_updated'));
      if (blocked) {actors.fail('actor_consequence_required');}
      const uid = socket.data.userId;
      const characterId = data.character?.id || data.characterId;
      if (data.character?.id && data.characterId !== data.character.id) {actors.fail('actor_binding_conflict');}
      const attachments = [];
      for (const map of Object.values(room.gameState.maps || {})) {
        for (const [id, token] of Object.entries(map.characterTokens || {})) {
          const contract = token.state?.actorContract;
          if (contract?.primary && contract.ownerUid === uid && contract.characterId === characterId) {
            if (token.ownerUserId !== uid || token.character?.id !== characterId) {actors.fail('actor_binding_conflict');}
            actors.prepareBuildUpdate(token, updates, 'character');
            attachments.push({ map, id, token });
          }
        }
      }
      if (attachments.length > 1) {actors.fail('actor_binding_conflict');}
      const projected = data.character ? roomAccess.projectCharacterForClient(data.character) : null;
      const nextCharacter = projected ? { ...player.character, ...projected } : player.character;
      for (const key of ['health', 'mana', 'actionPoints']) {
        if (projected?.[key]) {nextCharacter[key] = { ...player.character?.[key], ...projected[key] };}
      }
      // All refusals precede player/attachment installation; no asynchronous gap.
      if (attachments.length) {
        const attachment = attachments[0];
        attachment.prepared = actors.prepareBuildUpdate(attachment.token, { character: projected }, 'character');
        actors.installBuildUpdate(room, attachment.map, 'characterTokens', attachment.id, attachment.prepared);
        for (const key of ['health', 'mana', 'actionPoints', 'tempHealth', 'tempMana', 'tempActionPoints']) {
          nextCharacter[key] = attachment.prepared.token.character[key];
        }
      }
      if (data.character) {
        // P4: private inventory is never stored through a shared character
        // envelope; outbound delivery is additionally projected below.
        player.character = roomAccess.projectCharacterForClient({
          ...nextCharacter,
          lastUpdated: Date.now()
        });

        room.players.set(player.id, player);

        // CRITICAL FIX: Also update room.gm if this is the GM
        if (player.isGM || room.gm?.socketId === socket.id || room.gm?.id === player.id) {
          room.gm.character = player.character;
          logger.debug('[character_updated] Updated room.gm.character for GM sync');
        }
      }

      // CRITICAL FIX: Use room.id instead of data.roomId (which may be undefined)
      const broadcastRoomId = room.id;
      logger.debug('Broadcasting character_updated', {
        roomId: broadcastRoomId,
        playerId: player.id,
        isGM: player.isGM || room.gm?.socketId === socket.id
      });

      io.to(broadcastRoomId).emit('character_updated', {
        ...(attachments.length ? { roomId: room.id, actorSnapshot: require('../services/actorProjection').snapshot(room) } : {}),
        playerId: player.id,
        characterId: data.characterId,
        character: roomAccess.projectCharacterForClient(player.character),
        updatedBy: socket.id,
        senderSocketId: socket.id,
        senderUserId: socket.data.userId || null,
        isGM: player.isGM || room.gm?.socketId === socket.id,
        timestamp: Date.now()
      });

      logger.debug('[character_updated] Character updated', { playerId: player.id });

      if (room.isPermanent) {
        firebaseBatchWriter.queueWrite(room.id, room.gameState);
      }
      if (typeof ackCallback === 'function') {ackCallback({ success: true });}

    } catch (error) {
      logger.error('[character_updated] Error:', { error: error.message });
      require('../utils/socketAck').ackFailure(ackCallback, { success: false, code: error.code || 'invalid_bounds', error: error.message });
    }
  });

  socket.on('character_equipment_updated', async(data) => {
    try {
      const validation = validateRoomMembership(socket, data.roomId);
      if (!validation.valid) {return;}

      const { room, player } = validation;

      if (data.equipment && player.character) {
        player.character.equipment = {
          ...player.character.equipment,
          ...data.equipment
        };
        room.players.set(player.id, player);
      }

      socket.to(room.id).emit('character_equipment_updated', {
        playerId: player.id,
        equipment: roomAccess.projectEquipmentForClient(data.equipment),
        updatedBy: socket.id
      });

      if (room.isPermanent) {
        firebaseBatchWriter.queueWrite(room.id, room.gameState);
      }

    } catch (error) {
      logger.error('[character_equipment_updated] Error:', { error: error.message });
    }
  });

  socket.on('character_resource_updated', async(data, ack) => {
    try {
      const validation = validateRoomMembership(socket, data.roomId);
      if (!validation.valid) {return;}

      const { room, player: senderPlayer } = validation;

      let targetPlayer = null;
      let isGMUpdate = false;

      if (data.playerId) {
        targetPlayer = room.players.get(data.playerId);
      }

      if (!targetPlayer && room.gm && (socket.id === room.gm.socketId || data.senderSocketId === room.gm.socketId)) {
        targetPlayer = room.gm;
        isGMUpdate = true;
      }

      if (!targetPlayer && data.senderSocketId) {
        for (const [, p] of room.players) {
          if (p.socketId === data.senderSocketId) {
            targetPlayer = p;
            break;
          }
        }
      }

      if (!targetPlayer) {
        logger.warn('[character_resource_updated] Target player not found', {
          playerId: data.playerId,
          senderSocketId: data.senderSocketId,
          isGM: senderPlayer?.isGM
        });
        return;
      }

      // A non-GM may only modify their own resources; ignore client-supplied
      // playerId/senderSocketId that target another player.
      const isSelfTarget = senderPlayer && (
        targetPlayer.id === senderPlayer.id ||
        (targetPlayer.userId && targetPlayer.userId === senderPlayer.userId)
      );
      if (!senderPlayer?.isGM && !isSelfTarget) {
        logger.warn('[character_resource_updated] Non-GM attempted to modify another player', {
          senderId: senderPlayer?.id,
          targetId: targetPlayer.id
        });
        return;
      }

      // P9 fence: a pending owner spell approval reserves this player's class
      // home; legacy class-resource writes are refused before mutation/relay.
      if (data.resource === 'classResource' &&
        require('../services/spellPayments').pendingFor(room, targetPlayer.userId, targetPlayer.character?.id)) {
        socket.emit('room_error', { code: 'class_payment_pending', event: 'character_resource_updated',
          message: 'A spell payment awaiting GM adjudication reserves this class resource' });
        if (typeof ack === 'function') {ack({ success: false, code: 'class_payment_pending' });}
        return;
      }

      if (!targetPlayer.character) {
        targetPlayer.character = {};
      }

      if (data.resource === 'health') {
        targetPlayer.character.health = targetPlayer.character.health || { current: 0, max: 0 };
        targetPlayer.character.health.current = data.current;
        targetPlayer.character.health.max = data.max;
        if (data.temp !== undefined) {
          targetPlayer.character.tempHealth = data.temp;
        }
      } else if (data.resource === 'mana') {
        targetPlayer.character.mana = targetPlayer.character.mana || { current: 0, max: 0 };
        targetPlayer.character.mana.current = data.current;
        targetPlayer.character.mana.max = data.max;
        if (data.temp !== undefined) {
          targetPlayer.character.tempMana = data.temp;
        }
      } else if (data.resource === 'actionPoints') {
        targetPlayer.character.actionPoints = targetPlayer.character.actionPoints || { current: 0, max: 0 };
        targetPlayer.character.actionPoints.current = data.current;
        targetPlayer.character.actionPoints.max = data.max;
        if (data.temp !== undefined) {
          targetPlayer.character.tempActionPoints = data.temp;
        }
      } else if (data.resource === 'classResource') {
        if (data.classResource) {
          targetPlayer.character.classResource = data.classResource;
        } else {
          targetPlayer.character.classResource = targetPlayer.character.classResource || { current: 0, max: 0 };
          targetPlayer.character.classResource.current = data.current;
          targetPlayer.character.classResource.max = data.max;
        }
      }

      if (isGMUpdate) {
        room.gm = targetPlayer;
      } else {
        room.players.set(targetPlayer.id, targetPlayer);
      }

      io.to(data.roomId).emit('character_resource_updated', {
        playerId: targetPlayer.id,
        userId: targetPlayer.userId || targetPlayer.id,
        socketId: targetPlayer.socketId,
        playerName: targetPlayer.name,
        resource: data.resource,
        current: data.current,
        max: data.max,
        temp: data.temp,
        adjustment: data.adjustment,
        classResource: data.classResource,
        updatedBy: socket.id,
        senderSocketId: data.senderSocketId,
        isGM: isGMUpdate
      });

      logger.debug('[character_resource_updated] Resource updated', {
        playerId: targetPlayer.id,
        resource: data.resource,
        isGM: isGMUpdate
      });

      if (room.isPermanent) {
        firebaseBatchWriter.queueWrite(room.id, room.gameState);
      }

    } catch (error) {
      logger.error('[character_resource_updated] Error:', { error: error.message });
    }
  });

  socket.on('buff_update', async(data) => {
    try {
      const validation = validateRoomMembership(socket, data.roomId || data.data?.roomId);
      if (!validation.valid) {return;}

      const roomId = data.roomId || data.data?.roomId;
      const room = rooms.get(roomId);
      if (room) {
        if (!room.gameState.buffs) {room.gameState.buffs = {};}
        if (data.tokenId && data.buff) {
          room.gameState.buffs[data.tokenId] = data.buff;
        } else if (data.buffs) {
          room.gameState.buffs = { ...room.gameState.buffs, ...data.buffs };
        }
        firebaseBatchWriter.queueWrite(roomId, room.gameState);
      }

      socket.to(roomId).emit('buff_update', {
        ...data,
        senderSocketId: socket.id
      });
    } catch (error) {
      logger.error('[buff_update] Error:', { error: error.message });
    }
  });

  socket.on('debuff_update', async(data) => {
    try {
      const validation = validateRoomMembership(socket, data.roomId || data.data?.roomId);
      if (!validation.valid) {return;}

      const roomId = data.roomId || data.data?.roomId;
      const room = rooms.get(roomId);
      if (room) {
        if (!room.gameState.debuffs) {room.gameState.debuffs = {};}
        if (data.tokenId && data.debuff) {
          room.gameState.debuffs[data.tokenId] = data.debuff;
        } else if (data.debuffs) {
          room.gameState.debuffs = { ...room.gameState.debuffs, ...data.debuffs };
        }
        firebaseBatchWriter.queueWrite(roomId, room.gameState);
      }

      socket.to(roomId).emit('debuff_update', {
        ...data,
        senderSocketId: socket.id
      });
    } catch (error) {
      logger.error('[debuff_update] Error:', { error: error.message });
    }
  });
}

module.exports = { registerCharacterHandlers };
