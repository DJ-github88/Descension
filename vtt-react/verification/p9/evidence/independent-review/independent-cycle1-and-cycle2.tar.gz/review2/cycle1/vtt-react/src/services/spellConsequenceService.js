/** Original P9 runtime: producer routing, owner approval custody, GM adjudication
 * and receipt-only results. Stores remain projections of accepted P7 receipts. */
import { create } from 'zustand';
import { getStore } from '../store/storeRegistry';
import { normalizeManagedClassResource } from '../data/classResourceContracts';
import { canonical, sameExactRef } from './featherSlash';
import { supportSpell, buildApproval, planSpellCommand, spellReceipt, typedClassValue, P9_SPELL_EXECUTION } from './spellConsequence';
import { refOf, findActor, inSharedRoom, refreshActorSnapshot, prepareActorCommand, submitPreparedActorCommand, retryActorCommand,
  requestActorEvent, roomResourceProjection } from './actorConsequenceService';
import { spellContext, loadLatestSpell, retainLatestSpell, unresolvedSpell } from './spellConsequenceCustody';

export const useSpellConsequenceStore = create(() => ({ owner: null, ownerStatus: null, gmPending: {}, gmStatus: {} }));
const UNKNOWN = ['outcome_unknown', 'room_connection_unavailable', 'retired_principal', 'snapshot_required'];
const characterState = () => getStore('characterStore')?.getState() || {};
const gameState = () => getStore('gameStore')?.getState() || {};
const tokens = () => [...(getStore('creatureStore')?.getState().creatureTokens || []), ...(getStore('characterTokenStore')?.getState().characterTokens || [])];
const setOwnerStatus = ownerStatus => useSpellConsequenceStore.setState({ ownerStatus });
// Latest writer-confirmed checkpoint revision per room (from room_save_status only).
const confirmed = new Map();
function durabilityLabel(receipt, fallback) {
  if (receipt?.checkpointRevision === null) return 'live-only (temporary room)';
  const revision = receipt?.checkpointRevision, latest = confirmed.get(receipt?.roomId);
  if (Number.isSafeInteger(revision) && revision > 0 && Number.isSafeInteger(latest) && revision <= latest) return 'checkpoint-confirmed';
  return fallback === 'checkpoint-confirmed' ? fallback : 'accepted-live / checkpoint pending';
}

/** Support decision for the current shared-room caster; null when not in a room. */
export function spellSupport(spellLike) {
  if (!P9_SPELL_EXECUTION || !inSharedRoom()) return null;
  return supportSpell(spellLike, characterState());
}
export function spellDiagnostic(spellLike) {
  const support = spellSupport(spellLike);
  return support && !support.supported ? support.reason : null;
}
export const isP9Routed = spellLike => spellSupport(spellLike)?.supported === true;
/** Producer gate: a supported spell in a shared room opens the P9 panel and never
 * reaches a local pre-spend, cooldown or empty-target notice. */
export function routeSpellCast(spellLike, origin) {
  const support = spellSupport(spellLike);
  if (!support?.supported) return false;
  useSpellConsequenceStore.setState({ owner: { spellId: support.definitionId, origin: { producer: origin?.producer || 'unknown', slotIndex: origin?.slotIndex ?? null } } });
  return true;
}
export const closeOwnerPanel = () => useSpellConsequenceStore.setState({ owner: null });

/** The caster is the selected, matching owner primary attachment (P7 reconciliation). */
export function ownerSource() {
  const projection = roomResourceProjection();
  if (!projection) return { error: 'Select your owner attachment in the Party HUD first (exact owner, character, room and session).' };
  const token = findActor(projection.roomActorProjection.ref);
  if (!token || !token.state?.actorContract?.primary) return { error: 'Your primary room attachment is missing or retired.' };
  return { token, ref: refOf(token), mapId: token.mapId };
}
async function readHome(ref) {
  const result = await requestActorEvent('actor_recovery', { roomId: ref.roomId, ref });
  if (!result?.success) return { error: result?.code || 'recovery_unavailable' };
  const stored = result.recovery?.rawToken?.state?.classPayment;
  return { home: stored?.version === 1 ? { domain: stored.domain, value: stored.value } : null };
}
/** Owner-only sync of their own sheet value into the revisioned room home. */
async function syncHome(ref, payment) {
  const read = await readHome(ref);
  if (read.error) return { success: false, code: read.error };
  const wanted = { domain: payment.domain, value: payment.before };
  if (canonical(read.home) === canonical(wanted)) return { success: true, code: 'class_home_current' };
  const snapshot = await refreshActorSnapshot();
  if (!snapshot.success) return snapshot;
  const token = findActor(ref);
  if (!token) return { success: false, code: 'actor_not_found' };
  const command = prepareActorCommand([{ ref, expectedRevision: token.state.actorContract.revision, classPayment: { mode: 'sync', before: read.home, after: wanted } }]);
  return submitPreparedActorCommand(command);
}
function describeRefusal(code) {
  return `Not registered (${String(code || 'refused').replace(/_/g, ' ')}) — no payment was recorded.`;
}
/** Owner: approve the exact price/typed result with one recorded roll. */
export async function sendSpellApproval({ spellId, targetRef, roll, origin }) {
  const context = spellContext();
  if (!context.current()) return setOwnerStatus({ phase: 'refused', message: 'Sign in and join the room to cast with P9.' });
  const latest = loadLatestSpell(context);
  if (unresolvedSpell(latest)) return setOwnerStatus({ phase: latest.phase, message: 'An unresolved spell approval is retained; check or withdraw it first.', latest });
  const source = ownerSource();
  if (source.error) return setOwnerStatus({ phase: 'refused', message: source.error });
  let support = supportSpell({ id: spellId }, characterState());
  if (!support.supported) return setOwnerStatus({ phase: 'refused', message: support.reason });
  if (!support.payment.affordable) return setOwnerStatus({ phase: 'refused', message: support.payment.reason });
  if (support.payment.classPayment) {
    setOwnerStatus({ phase: 'syncing', message: 'Publishing your current class resource to the room…' });
    const synced = await syncHome(source.ref, support.payment.classPayment);
    if (!synced.success) return setOwnerStatus({ phase: 'refused', message: `Class resource sync refused (${synced.code}); nothing submitted.` });
  }
  const snapshot = await refreshActorSnapshot();
  if (!snapshot.success) return setOwnerStatus({ phase: 'refused', message: `Room snapshot unavailable (${snapshot.code}); nothing submitted.` });
  support = supportSpell({ id: spellId }, characterState());
  const current = ownerSource();
  if (current.error) return setOwnerStatus({ phase: 'refused', message: current.error });
  let approval;
  try {
    approval = buildApproval({ support, tokens: tokens(), sourceRef: current.ref, targetRef, roomId: snapshot.roomId, mapId: current.mapId,
      actionEpoch: snapshot.actionEpoch, roll, approvalId: crypto.randomUUID() });
  } catch (error) { return setOwnerStatus({ phase: 'refused', message: error.message }); }
  let retained;
  try { retained = retainLatestSpell(context, { phase: 'prepared', approval, origin, cooldown: support.cooldown }); } catch (error) { return setOwnerStatus({ phase: 'refused', message: error.message }); }
  return submitApproval(context, retained);
}
async function submitApproval(context, retained) {
  setOwnerStatus({ phase: 'awaiting', message: 'Submitting approval…', latest: retained });
  const result = await requestActorEvent('actor_spell_approve', retained.approval);
  if (!context.current()) return { success: false, code: 'retired_principal' };
  if (result.success) { consumeSpellReceipt(result); return result; }
  if (result.code === 'awaiting_gm') {
    const kept = retainLatestSpell(context, { ...retained, phase: 'awaiting', contentHash: result.contentHash });
    return setOwnerStatus({ phase: 'awaiting', message: 'Awaiting GM adjudication. Nothing is spent until the GM accepts.', latest: kept });
  }
  if (UNKNOWN.includes(result.code)) {
    const kept = retainLatestSpell(context, { ...retained, phase: 'unknown' });
    return setOwnerStatus({ phase: 'unknown', message: 'Outcome unknown. Check this same approval; it will not reroll or pay twice.', latest: kept });
  }
  const kept = retainLatestSpell(context, { ...retained, phase: 'refused', result });
  return setOwnerStatus({ phase: 'refused', message: describeRefusal(result.code), latest: kept });
}
/** Owner: re-send the exact retained approval bytes (idempotent on the server). */
export async function checkSpellApproval() {
  const context = spellContext(), latest = loadLatestSpell(context);
  if (!latest?.approval) return setOwnerStatus({ phase: 'idle', message: 'No retained spell approval.' });
  return submitApproval(context, latest);
}
export async function withdrawSpellApproval() {
  const context = spellContext(), latest = loadLatestSpell(context);
  if (!latest?.approval) return null;
  const result = await requestActorEvent('actor_spell_withdraw', { roomId: latest.approval.roomId, approvalId: latest.approval.approvalId });
  if (!context.current()) return null;
  if (result.success && result.receipt) { consumeSpellReceipt(result); return result; }
  if (result.success && result.code === 'withdrawn') {
    const kept = retainLatestSpell(context, { ...latest, phase: 'withdrawn', result });
    return setOwnerStatus({ phase: 'withdrawn', message: 'Withdrawn before GM acceptance — no payment was recorded.', latest: kept });
  }
  return setOwnerStatus({ phase: latest.phase, message: `Withdrawal not confirmed (${result.code}); the approval may still be accepted.`, latest });
}
/** Owner: approve again after the class price/typed result changed. Same roll. */
export async function reapproveSpell() {
  const context = spellContext(), latest = loadLatestSpell(context);
  if (latest?.phase !== 'reapproval') return null;
  const source = ownerSource();
  if (source.error) return setOwnerStatus({ phase: 'reapproval', message: source.error, latest });
  let support = supportSpell({ id: latest.approval.spell.definitionId }, characterState());
  if (!support.supported || !support.payment.affordable) return setOwnerStatus({ phase: 'reapproval', message: support.reason || support.payment?.reason, latest });
  if (support.reading.reading !== latest.approval.roll.reading) return setOwnerStatus({ phase: 'reapproval', message: 'Your formula reading changed; cancel and record a new roll explicitly.', latest });
  if (support.payment.classPayment) {
    const synced = await syncHome(source.ref, support.payment.classPayment);
    if (!synced.success) return setOwnerStatus({ phase: 'reapproval', message: `Class resource sync refused (${synced.code}).`, latest });
  }
  const snapshot = await refreshActorSnapshot();
  if (!snapshot.success) return setOwnerStatus({ phase: 'reapproval', message: `Room snapshot unavailable (${snapshot.code}).`, latest });
  support = supportSpell({ id: latest.approval.spell.definitionId }, characterState());
  let approval;
  try {
    approval = buildApproval({ support, tokens: tokens(), sourceRef: latest.approval.source, targetRef: latest.approval.target, roomId: snapshot.roomId,
      mapId: latest.approval.source.mapId, actionEpoch: snapshot.actionEpoch, roll: latest.approval.roll, approvalId: crypto.randomUUID() });
  } catch (error) { return setOwnerStatus({ phase: 'reapproval', message: error.message, latest }); }
  const retained = retainLatestSpell(context, { phase: 'prepared', approval, origin: latest.origin, cooldown: latest.cooldown, supersedes: latest.approval.approvalId });
  return submitApproval(context, retained);
}
export function restoreOwnerStatus() {
  const latest = loadLatestSpell();
  if (!latest) return null;
  const messages = { awaiting: 'Awaiting GM adjudication. Nothing is spent until the GM accepts.', unknown: 'Outcome unknown. Check this same approval.',
    reapproval: 'The class price or typed result changed. Review and approve again (same roll).', accepted: 'Accepted.', refused: describeRefusal(latest.result?.code),
    withdrawn: 'Withdrawn before GM acceptance — no payment was recorded.', declined: 'Declined by the GM before acceptance — no payment was recorded.', prepared: 'Prepared; check this same approval.' };
  return setOwnerStatus({ phase: latest.phase, message: messages[latest.phase] || latest.phase, latest });
}

// ── Owner reconciliation of an accepted result ─────────────────────────────
function applyOwnerClass(view, approval) {
  const projection = roomResourceProjection();
  if (!projection || !sameExactRef(projection.roomActorProjection.ref, view.receipt.source)) return 'not-active-attachment';
  const store = getStore('characterStore'), state = store.getState();
  const payment = approval?.classPayment;
  if (!payment) return 'no-class-payment';
  const personal = typedClassValue(state.classResource, state.class, payment.domain);
  if (canonical(personal) !== canonical(payment.before)) {
    // A sheet edit during the pending window is preserved, never silently lost.
    const prior = state.roomActorRecoveryCandidates || [];
    if (prior.length >= 8) return 'candidate-capacity';
    store.setState({ roomActorRecoveryCandidates: [...prior, { ownerUid: view.receipt.source.ownerUid, characterId: view.receipt.source.characterId, ref: view.receipt.source,
      reason: 'p9-class-edit-during-pending-approval', data: { classResource: JSON.parse(JSON.stringify(state.classResource)) } }] });
  }
  store.setState({ classResource: { ...normalizeManagedClassResource({ ...state.classResource, ...payment.after }, state.class), lastUpdate: Date.now() } });
  try { require('../store/characterHelpers').triggerCharacterAutoSave(() => store.getState().saveCurrentCharacter()); } catch (_) { /* P6 status remains visible */ }
  return 'applied';
}
async function applyOwnerClassFromHome(view) {
  const projection = roomResourceProjection();
  if (!projection || !sameExactRef(projection.roomActorProjection.ref, view.receipt.source)) return;
  const read = await readHome(view.receipt.source);
  const store = getStore('characterStore'), state = store.getState();
  if (!read.home || !roomResourceProjection()) return;
  store.setState({ classResource: { ...normalizeManagedClassResource({ ...state.classResource, ...read.home.value }, state.class), lastUpdate: Date.now() } });
}
function startCooldown(origin, cooldown, spellId) {
  if (origin?.producer !== 'hud' || !Number.isInteger(origin.slotIndex) || !cooldown || cooldown.type === 'none' || !(cooldown.value > 0)) return;
  try { window.dispatchEvent(new CustomEvent('mythrill:p9-spell-accepted', { detail: { slotIndex: origin.slotIndex, spellId, cooldown } })); } catch (_) { /* no window */ }
}
/** Every client derives results from the accepted receipt only (deduplicated). */
export function consumeSpellReceipt(result) {
  const view = spellReceipt(result);
  if (!view || view.receipt.roomId !== gameState().multiplayerRoom?.id) return null;
  const id = `p9:${view.receipt.roomId}:${view.receipt.submitterUid}:${view.receipt.commandId}`;
  const chat = getStore('chatStore');
  const { recorded, receipt } = view, adjudication = receipt.adjudication;
  if (chat && !chat.getState().notifications.combat.some(note => note.id === id)) chat.getState().addNotification('combat', {
    id, type: 'combat', receiptId: id, timestamp: new Date(receipt.acceptedAt).toISOString(),
    content: `${recorded.sourceName} → ${recorded.targetName}: ${recorded.spellName} · ${recorded.roll.mode} [${recorded.roll.dice.map(group => group.faces.join(', ')).join(' | ')}] ${recorded.roll.constant >= 0 ? '+' : '-'} ${Math.abs(recorded.roll.constant)} = ${recorded.roll.total}; GM final ${adjudication.finalAmount} ${recorded.kind === 'healing' ? 'healing' : (recorded.damageTypes || []).join('/')}${adjudication.adjustmentReason ? ` (${adjudication.adjustmentReason})` : ''}. Accepted receipt ${receipt.commandId}.`
  });
  useSpellConsequenceStore.setState(current => {
    const gmPending = { ...current.gmPending }; delete gmPending[view.approvalId];
    const gmStatus = { ...current.gmStatus, ...(current.gmStatus[view.approvalId] ? { [view.approvalId]: { phase: 'accepted', checkpointRevision: view.receipt.checkpointRevision, message: `Accepted · ${durabilityLabel(view.receipt, view.status)}` } } : {}) };
    return { gmPending, gmStatus };
  });
  const context = spellContext();
  if (context.current() && view.receipt.source.ownerUid === context.uid) {
    const latest = loadLatestSpell(context);
    if (latest?.approval?.approvalId === view.approvalId) {
      if (latest.phase !== 'accepted') {
        applyOwnerClass(view, latest.approval);
        startCooldown(latest.origin, latest.cooldown, view.receipt.adjudication.definitionId);
      }
      const kept = retainLatestSpell(context, { ...latest, phase: 'accepted', result });
      setOwnerStatus({ phase: 'accepted', message: `Accepted · ${durabilityLabel(view.receipt, view.status)}. GM final ${adjudication.finalAmount}.`, latest: kept });
    } else if (view.receipt.source.characterId === characterState().currentCharacterId) {
      applyOwnerClassFromHome(view);
    }
  }
  return view;
}

// ── GM adjudication ─────────────────────────────────────────────────────────
const setGm = (approvalId, status) => useSpellConsequenceStore.setState(current => ({ gmStatus: { ...current.gmStatus, [approvalId]: { ...current.gmStatus[approvalId], ...status } } }));
export async function refreshSpellApprovals() {
  const roomId = gameState().multiplayerRoom?.id;
  if (!roomId) return null;
  const result = await requestActorEvent('actor_spell_list', { roomId });
  if (!result?.success) return result;
  const gmPending = {};
  for (const entry of result.pending || []) if (!entry.own) gmPending[entry.approval.approvalId] = entry;
  useSpellConsequenceStore.setState({ gmPending });
  return result;
}
export async function gmAcceptSpell(approvalId, { finalAmount, reason, adjudicated }) {
  const entry = useSpellConsequenceStore.getState().gmPending[approvalId];
  if (!entry) return setGm(approvalId, { phase: 'refused', message: 'Approval no longer pending.' });
  const snapshot = await refreshActorSnapshot();
  if (!snapshot.success) return setGm(approvalId, { phase: 'refused', message: `Room snapshot unavailable (${snapshot.code}).` });
  let command;
  try {
    const plan = planSpellCommand({ approval: entry.approval, contentHash: entry.contentHash, tokens: tokens(), roomId: snapshot.roomId, mapId: entry.approval.source.mapId,
      finalAmount, reason, adjudicated });
    command = prepareActorCommand(plan.entries, plan.extra);
  } catch (error) { return setGm(approvalId, { phase: 'refused', message: `${error.message} Nothing submitted.` }); }
  setGm(approvalId, { phase: 'submitting', commandId: command.commandId, message: 'Submitting one consequence…' });
  const result = await submitPreparedActorCommand(command);
  return settleGm(approvalId, command.commandId, result);
}
function settleGm(approvalId, commandId, result) {
  if (result.success) {
    consumeSpellReceipt(result);
    return setGm(approvalId, { phase: 'accepted', checkpointRevision: result.receipt?.checkpointRevision, message: `Accepted · ${durabilityLabel(result.receipt, result.status)}` });
  }
  if (UNKNOWN.includes(result.code)) return setGm(approvalId, { phase: 'unknown', commandId, message: 'Outcome unknown. Check this same command; it will not be rebuilt or resubmitted with new values.' });
  if (result.code === 'owner_reapproval_required') return setGm(approvalId, { phase: 'reapproval', message: 'The class price or typed result changed. The owner must approve again; nothing was applied.' });
  if (['stale_actor_revision', 'insufficient_resources'].includes(result.code)) return setGm(approvalId, { phase: 'retry', message: `Actors changed (${result.code.replace(/_/g, ' ')}). Nothing was applied; review and accept again.` });
  return setGm(approvalId, { phase: 'refused', message: `Refused (${String(result.code || 'refused').replace(/_/g, ' ')}); nothing was applied.` });
}
export async function gmCheckSpellCommand(approvalId) {
  const status = useSpellConsequenceStore.getState().gmStatus[approvalId];
  if (!status?.commandId) return null;
  return settleGm(approvalId, status.commandId, await retryActorCommand(status.commandId));
}
export async function gmDeclineSpell(approvalId) {
  const result = await requestActorEvent('actor_spell_decline', { roomId: gameState().multiplayerRoom?.id, approvalId });
  if (result.success && result.receipt) { consumeSpellReceipt(result); return result; }
  if (result.success) {
    useSpellConsequenceStore.setState(current => { const gmPending = { ...current.gmPending }; delete gmPending[approvalId]; return { gmPending }; });
    return setGm(approvalId, { phase: 'declined', message: 'Declined before acceptance; no payment was recorded.' });
  }
  return setGm(approvalId, { phase: 'refused', message: `Decline not confirmed (${result.code}).` });
}

export function registerSpellConsequenceHandlers({ socket }) {
  if (!socket) return () => {};
  const live = () => gameState().multiplayerSocket === socket;
  // The server delivers pending approvals to entitled GM sessions only.
  const pending = value => {
    if (!live() || value?.roomId !== gameState().multiplayerRoom?.id || !value.approval?.approvalId) return;
    useSpellConsequenceStore.setState(current => ({ gmPending: { ...current.gmPending, [value.approval.approvalId]: value } }));
  };
  const closed = value => {
    if (!live() || value?.roomId !== gameState().multiplayerRoom?.id) return;
    useSpellConsequenceStore.setState(current => { const gmPending = { ...current.gmPending }; delete gmPending[value.approvalId]; return { gmPending }; });
    const context = spellContext(), latest = loadLatestSpell(context);
    if (latest?.approval?.approvalId !== value.approvalId || latest.phase === 'accepted') return;
    const phase = value.code === 'owner_reapproval_required' ? 'reapproval' : value.code === 'declined' ? 'declined' : value.code === 'withdrawn' ? 'withdrawn' : latest.phase;
    const kept = retainLatestSpell(context, { ...latest, phase });
    setOwnerStatus({ phase, latest: kept, message: phase === 'reapproval' ? 'The class price or typed result changed. Review and approve again (same roll).'
      : phase === 'declined' ? 'Declined by the GM before acceptance — no payment was recorded.' : phase === 'withdrawn' ? 'Withdrawn before GM acceptance — no payment was recorded.' : latest.phase });
  };
  const accepted = result => { if (live()) consumeSpellReceipt(result); };
  // Checkpoint confirmation upgrades the accepted label only from the writer's confirmed revision.
  const saved = value => {
    if (!live() || value?.roomId !== gameState().multiplayerRoom?.id || !Number.isSafeInteger(value.confirmedRevision)) return;
    confirmed.set(value.roomId, Math.max(confirmed.get(value.roomId) || 0, value.confirmedRevision));
    const { ownerStatus, gmStatus } = useSpellConsequenceStore.getState();
    const revision = ownerStatus?.latest?.result?.receipt?.checkpointRevision;
    if (ownerStatus?.phase === 'accepted' && Number.isSafeInteger(revision) && revision > 0 && revision <= value.confirmedRevision) {
      setOwnerStatus({ ...ownerStatus, message: ownerStatus.message.replace('accepted-live / checkpoint pending', 'checkpoint-confirmed') });
    }
    for (const [id, status] of Object.entries(gmStatus)) {
      if (status.phase === 'accepted' && Number.isSafeInteger(status.checkpointRevision) && status.checkpointRevision > 0 && status.checkpointRevision <= value.confirmedRevision && !status.message.includes('checkpoint-confirmed')) {
        setGm(id, { message: 'Accepted · checkpoint-confirmed' });
      }
    }
  };
  socket.on('actor_spell_pending', pending); socket.on('actor_spell_closed', closed); socket.on('actor_consequence_accepted', accepted); socket.on('room_save_status', saved);
  return () => { socket.off('actor_spell_pending', pending); socket.off('actor_spell_closed', closed); socket.off('actor_consequence_accepted', accepted); socket.off('room_save_status', saved); };
}
