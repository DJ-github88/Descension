const { src } = require('./hook.cjs');
const S = require(src('services/spellConsequence.js'));
const rows = [];
for (const first of [true, false]) for (const code of ['class_home_required', 'forbidden', 'approval_withdrawn', 'approval_declined', 'approval_owner_reapproval_required', 'approval_consumed', 'retry_window_expired', 'command_id_conflict', 'invalid_spell_approval'])
  rows.push(['owner', first ? 'first' : 'recheck', code, S.ownerRefusal(first, code)]);
for (const retry of [false, true]) for (const code of ['retry_window_expired', 'stale_actor_revision', 'approval_consumed', 'approval_mismatch', 'owner_reapproval_required', 'forbidden'])
  rows.push(['gm', retry ? 'retry' : 'first', code, S.gmRefusal(retry, code)]);
for (const r of rows) console.log(r[0], r[1], r[2], '=>', r[3].phase, '|', r[3].message);
// N3
console.log('N3 prayer undefined classResource:', JSON.stringify(S.supportSpell({ id: 'martyr_restorative_prayer' }, { class: 'Martyr', stats: { spirit: 14 } })));
const st = { strength: 12, agility: 14, constitution: 9, intelligence: 16, spirit: 14, charisma: 7 };
console.log('R7', JSON.stringify(['1d8 + intelligence/4', '1d8 + int', '1d8 + intelligencemod'].map(f => S.readFormula(f, st).supported ? S.readFormula(f, st).constant : 'manual')));
