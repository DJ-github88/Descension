// Scratch require hook: transpile vtt-react/src ESM/JSX to CJS for pure-module probes.
const path = require('path'), fs = require('fs'), Module = require('module');
const VR = '/home/claude/dj-github88/descension/vtt-react';
const req = Module.createRequire(path.join(VR, 'package.json'));
const babel = req('@babel/core');
const orig = Module._extensions['.js'];
const compile = (module, file) => {
  if (file.startsWith(path.join(VR, 'src'))) {
    const code = babel.transformSync(fs.readFileSync(file, 'utf8'), { filename: file, babelrc: false, configFile: false,
      presets: [[req.resolve('@babel/preset-react'), { runtime: 'classic' }]], plugins: [req.resolve('@babel/plugin-transform-modules-commonjs')] }).code;
    module._compile(code, file);
  } else orig(module, file);
};
Module._extensions['.js'] = compile; Module._extensions['.jsx'] = compile;
for (const ext of ['.css', '.png', '.svg', '.jpg']) Module._extensions[ext] = m => { m.exports = {}; };
global.window = global.window || { addEventListener() {}, removeEventListener() {}, dispatchEvent() {}, localStorage: { getItem: () => null, setItem() {}, removeItem() {} } };
global.localStorage = global.window.localStorage;
module.exports = { VR, src: p => path.join(VR, 'src', p) };
