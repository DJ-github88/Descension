const { src } = require('./hook.cjs');
const assert = require('assert/strict');
const S = require(src('services/spellConsequence.js'));
const { CLASS_DATA_MAP } = require(src('data/classSpellGenerator.js'));
const out = {};
// R7 formula vocabulary
const st = { strength: 12, agility: 14, constitution: 9, intelligence: 16, spirit: 14, charisma: 7 };
const read = f => { const r = S.readFormula(f, st); return r.supported ? `${r.dice.map(d => d.count + 'd' + d.sides).join('+')}${r.constant >= 0 ? '+' : ''}${r.constant}` : 'MANUAL: ' + r.reason; };
out.formulas = Object.fromEntries(['1d8 + intelligence/4', '1d4 + spirit', '2d6 + intelligence_modifier', '1d6 + intelligencemod', '1d6 + constitution_modifier', '1d6 + constitutionmod', '1d6 - charisma_modifier',
  '1d8 + int', '1d8 + intmod', '1d8 + int_modifier', '1d8 + str', '1d8 + wis', '1d8 + dex', '1d8 + intellect', '1d8 + intellect/4', '1d8 + agi/2', '1d8 + 2*intelligence', '1d8 + (intelligence)', '1d8 + 10%',
  '1d8 + spirit/3', '1d8 + constitution/4', 'intelligence', '1d8 + wisdom', '1d8 + intelligence/0', '1d8 + Intelligence'].map(f => [f, read(f)]));
assert.equal(out.formulas['1d8 + intelligence/4'], '1d8+4');
assert.equal(out.formulas['1d4 + spirit'], '1d4+14');
assert.equal(out.formulas['2d6 + intelligence_modifier'], '2d6+3');
assert.equal(out.formulas['1d6 + constitution_modifier'], '1d6-1');
assert.equal(out.formulas['1d6 + constitutionmod'], '1d6-1');
assert.equal(out.formulas['1d6 - charisma_modifier'], '1d6+2');
assert.equal(out.formulas['1d8 + spirit/3'], '1d8+4');
assert.equal(out.formulas['1d8 + constitution/4'], '1d8+2');
for (const f of ['1d8 + int', '1d8 + intmod', '1d8 + int_modifier', '1d8 + str', '1d8 + wis', '1d8 + dex', '1d8 + intellect', '1d8 + intellect/4', '1d8 + agi/2', '1d8 + 2*intelligence', '1d8 + (intelligence)', '1d8 + 10%', 'intelligence', '1d8 + wisdom', '1d8 + intelligence/0']) assert.match(out.formulas[f], /^MANUAL/, f);
// dynamic evaluator is not used: source text check
const fs = require('fs');
out.dynamicEvaluatorReferences = ['services/spellConsequence.js', 'services/spellConsequenceService.js', 'components/hud/SpellConsequencePanel.jsx'].filter(p => /resolveDynamicSpellFormula/.test(fs.readFileSync(src(p), 'utf8')));
assert.deepEqual(out.dynamicEvaluatorReferences, []);
// S1 support over every authored class spell with a generic caster per class (class resource normalized from defaults)
const supported = [];
const reasons = {};
for (const [cls, data] of Object.entries(CLASS_DATA_MAP)) {
  for (const spell of data.spells || []) {
    const shape = S.supportShape(spell);
    if (!shape.supported) { reasons[shape.reason.slice(0, 50)] = (reasons[shape.reason.slice(0, 50)] || 0) + 1; continue; }
    let pay; try { pay = S.planClassPayment(spell, undefined, cls); } catch (e) { pay = { supported: false, reason: 'THROWS with undefined classResource: ' + e.message }; }
    supported.push({ cls, id: spell.id, payment: pay.supported ? pay.domain : 'MANUAL: ' + pay.reason, formula: shape.formula, price: shape.price, cooldown: shape.cooldown });
  }
}
out.shapeSupported = supported;
out.topManualReasons = Object.entries(reasons).sort((a, b) => b[1] - a[1]).slice(0, 12);
console.log(JSON.stringify(out, null, 1));
