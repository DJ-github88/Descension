/** Independent reviewer scratch probes against the real registered stack (not production code). */
const S = '/home/claude/dj-github88/descension/server';
const assert = require('assert/strict');
const crypto = require('crypto');
const { createProductionStackServer } = require(`${S}/tests/helpers/productionStackServer`);
const { FirebaseBatchWriter } = require(`${S}/services/syncService`);
const actors = require(`${S}/services/actorConsequences`);
const payments = require(`${S}/services/spellPayments`);
const ack = (client, event, payload) => new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error(`ack timeout: ${event}`)), 8000);
  client.emit(event, payload, result => {clearTimeout(timer); resolve(result);});
});
const once = (client, event) => new Promise(resolve => client.once(event, resolve));
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const DEF_HASH = `p9-spell:v1/${sha('arc_spark_bolt')}`;
const log = [];
const note = (...a) => {log.push(a.map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(' ')); console.log('    PROBE', ...a.map(x => typeof x === 'string' ? x : JSON.stringify(x)));};

describe('Reviewer probes (registered production stack)', function() {
  this.timeout(120000);
  let server, writer, gm, owner, other, gmUid, ownerUid, otherUid, room, pcRef, foeRef, clients, epoch, seen;
  beforeEach(async() => {
    writer = new FirebaseBatchWriter(5, 50, { shouldPersist: () => true, persist: async() => ({ outcome: 'confirmed' }) });
    server = createProductionStackServer({ firebaseBatchWriter: writer });
    await server.start(); clients = []; seen = { gm: [], owner: [], other: [] };
    for (const event of ['actor_bind', 'actor_consequence', 'actor_snapshot', 'actor_spell_approve', 'actor_spell_withdraw', 'actor_spell_decline', 'actor_spell_list', 'actor_recovery', 'character_resource_updated', 'actor_propose', 'actor_adjudicate', 'join_room']) {
      server.setEventLimits(event, { maxPerMinute: 200000, maxPerSecond: 200000 });
    }
    gmUid = server.nextUserId(); ownerUid = server.nextUserId(); otherUid = server.nextUserId();
    server.registerAuthToken('gm', gmUid); server.registerAuthToken('owner', ownerUid); server.registerAuthToken('other', otherUid);
    gm = server.connect({ token: 'gm' }); clients.push(gm); await once(gm, 'connect');
    gm.onAny((event, payload) => seen.gm.push({ event, payload }));
    room = await server.seedRoom(gm.id, { gmUserId: gmUid, persistentRoomId: crypto.randomUUID() });
    for (const [token, name] of [['owner', 'Owner'], ['other', 'Other']]) {
      const client = server.connect({ token }); clients.push(client); await once(client, 'connect');
      client.onAny((event, payload) => seen[token].push({ event, payload }));
      const joined = once(client, 'room_joined'); client.emit('join_room', { roomId: room.id, playerName: name, password: '' }); await joined;
      if (token === 'owner') {owner = client;} else {other = client;}
    }
    server.players.get(owner.id).character = { id: 'ilse', class: 'Arcanoneer', classResource: { type: 'elementalSpheres', spheres: ['arcane', 'arcane', 'ember'], current: 3, max: 12 } };
    server.setCharacterOwner('ilse', ownerUid);
    const pc = { id: 'pc', ownerUserId: ownerUid, character: { id: 'ilse', name: 'Ilse', class: 'Arcanoneer', health: { current: 20, max: 40 }, mana: { current: 30, max: 30 },
      actionPoints: { current: 5, max: 5 }, tempHealth: 0, tempMana: 3, tempActionPoints: 1, classResource: { type: 'elementalSpheres', spheres: ['arcane', 'arcane', 'ember'] } }, state: { conditions: [] } };
    const foe = { id: 'foe', creatureId: 'grimmstalk', stats: { maxHp: 250, maxMana: 30, maxAP: 5 }, state: { currentHp: 200, tempHealth: 4, currentMana: 0, tempMana: 0, currentActionPoints: 2, tempActionPoints: 0, conditions: [] } };
    room.gameState.maps.default.characterTokens.pc = pc; room.gameState.maps.default.tokens.foe = foe;
    pcRef = (await ack(gm, 'actor_bind', { roomId: room.id, ref: { kind: 'character', roomId: room.id, mapId: 'default', tokenId: 'pc', ownerUid, characterId: 'ilse' }, snapshotHash: actors.hash(pc) })).ref;
    foeRef = (await ack(gm, 'actor_bind', { roomId: room.id, ref: { kind: 'creature', roomId: room.id, mapId: 'default', tokenId: 'foe' }, snapshotHash: actors.hash(foe) })).ref;
    epoch = (await ack(owner, 'actor_snapshot', { roomId: room.id })).actionEpoch;
  });
  afterEach(async() => {for (const client of clients) {client.disconnect();} await server.stop();});
  const snap = async client => ack(client, 'actor_snapshot', { roomId: room.id });
  const revision = ref => actors.locate(room, ref).contract.revision;
  const command = async(client, entries, extra = {}) => ({ version: 1, roomId: room.id, commandId: crypto.randomUUID(), actionEpoch: epoch,
    baseCommitSequence: (await snap(client)).commitSequence, actors: entries, ...extra });
  const spheres = list => ({ type: 'elementalSpheres', spheres: list });
  const sync = async(before, after) => ack(owner, 'actor_consequence', await command(owner, [{ ref: pcRef, expectedRevision: revision(pcRef), classPayment: { mode: 'sync', before, after } }]));
  const approval = (extra = {}) => ({ version: 1, roomId: room.id, approvalId: crypto.randomUUID(), actionEpoch: epoch, source: pcRef, target: foeRef,
    spell: { definitionId: 'arc_spark_bolt', definitionHash: DEF_HASH, name: 'Marrow-Piercing Slug', kind: 'damage', damageTypes: ['arcane'] },
    roll: { mode: 'physical', dice: [{ sides: 8, faces: [6] }], constant: 4, total: 10, reading: '1d8 + intelligence/4 → 1d8 + 4' },
    price: { ap: 1, mana: 4 },
    classPayment: { domain: 'elementalSpheres', before: spheres(['arcane', 'arcane', 'ember']), after: spheres(['ember']), price: { costs: ['arcane', 'arcane'], gains: [] } }, ...extra });
  const tempFirst = (current, temp, cost) => ({ current: current - Math.max(0, cost - temp), temp: Math.max(0, temp - cost) });
  const gmCommand = async(approved, contentHash, client = gm) => {
    const final = 7;
    const chosen = JSON.stringify({ capability: 'p9-spell:v1', approvalId: approved.approvalId, roll: approved.roll, kind: approved.spell.kind, damageTypes: approved.spell.damageTypes, gmConfirmed: true });
    const source = actors.locate(room, pcRef).token, foe = actors.locate(room, foeRef).token;
    return command(client, [
      { ref: pcRef, expectedRevision: revision(pcRef), finalResources: { ap: tempFirst(source.character.actionPoints.current, source.character.tempActionPoints, approved.price.ap),
        mana: tempFirst(source.character.mana.current, source.character.tempMana, approved.price.mana) },
      ...(approved.classPayment ? { classPayment: { mode: 'spell', domain: approved.classPayment.domain, approvalHash: contentHash } } : {}) },
      { ref: foeRef, expectedRevision: revision(foeRef), finalResources: { hp: { current: Math.max(0, foe.state.currentHp - Math.max(0, final - foe.state.tempHealth)), temp: Math.max(0, foe.state.tempHealth - final) } } }],
    { source: pcRef, target: foeRef, approval: { approvalId: approved.approvalId, contentHash },
      adjudication: { definitionId: 'arc_spark_bolt', definitionVersionOrHash: DEF_HASH, chosenResult: chosen, finalAmount: final, adjustmentReason: 'GM ruling' } });
  };
  const pools = () => { const c = actors.locate(room, pcRef).token.character; return { ap: [c.actionPoints.current, c.tempActionPoints], mana: [c.mana.current, c.tempMana] }; };

  it('PA: approval consumed through the P8 actor_propose/actor_adjudicate route', async() => {
    await sync(null, { domain: 'elementalSpheres', value: spheres(['arcane', 'arcane', 'ember']) });
    const approved = approval();
    const registered = await ack(owner, 'actor_spell_approve', approved);
    assert.equal(registered.code, 'awaiting_gm');
    const cmd = await gmCommand(approved, registered.contentHash, owner); // owner builds the same strict command
    const proposalPending = once(gm, 'actor_proposal_pending');
    const proposed = await ack(owner, 'actor_propose', cmd);
    note('PA propose ->', proposed.code);
    const pending = await proposalPending;
    const adjudicated = await ack(gm, 'actor_adjudicate', { roomId: room.id, proposalId: pending.proposalId, contentHash: pending.contentHash });
    note('PA adjudicate ->', { success: adjudicated.success, code: adjudicated.code, authorization: adjudicated.receipt?.authorization });
    note('PA home after', actors.locate(room, pcRef).token.state.classPayment, 'pools', pools());
    note('PA approval still registered?', !!payments.get(room, approved.approvalId), 'pendingFor owner?', !!payments.pendingFor(room, ownerUid, 'ilse'));
    const fence = await ack(owner, 'character_resource_updated', { roomId: room.id, resource: 'classResource', classResource: spheres(['storm']), playerId: server.players.get(owner.id).id });
    note('PA legacy class write after acceptance ->', fence);
    note('PA new approval after acceptance ->', (await ack(owner, 'actor_spell_approve', approval({ classPayment: { domain: 'elementalSpheres', before: spheres(['ember']), after: spheres([]), price: { costs: ['ember'], gains: [] } } }))).code);
    note('PA owner sync after acceptance ->', (await sync({ domain: 'elementalSpheres', value: spheres(['ember']) }, { domain: 'elementalSpheres', value: spheres(['storm']) })).code);
    const w = await ack(owner, 'actor_spell_withdraw', { roomId: room.id, approvalId: approved.approvalId });
    note('PA withdraw ->', { success: w.success, code: w.code, receipt: !!w.receipt }, 'still registered?', !!payments.get(room, approved.approvalId));
    const d = await ack(gm, 'actor_spell_decline', { roomId: room.id, approvalId: approved.approvalId });
    note('PA decline ->', { success: d.success, code: d.code, receipt: !!d.receipt }, 'still registered?', !!payments.get(room, approved.approvalId));
    note('PA gm list ->', (await ack(gm, 'actor_spell_list', { roomId: room.id })).pending.map(p => p.approval.approvalId === approved.approvalId));
  });

  it('PA2: classPayment-null approval consumed twice when the first acceptance goes through actor_adjudicate', async() => {
    const approved = approval({ classPayment: null });
    const registered = await ack(owner, 'actor_spell_approve', approved);
    assert.equal(registered.code, 'awaiting_gm', JSON.stringify(registered));
    const before = pools();
    const cmd = await gmCommand(approved, registered.contentHash, owner);
    const proposalPending = once(gm, 'actor_proposal_pending');
    await ack(owner, 'actor_propose', cmd);
    const pending = await proposalPending;
    const first = await ack(gm, 'actor_adjudicate', { roomId: room.id, proposalId: pending.proposalId, contentHash: pending.contentHash });
    const second = await ack(gm, 'actor_consequence', await gmCommand(approved, registered.contentHash));
    note('PA2 first(adjudicate) ->', first.success, first.receipt?.authorization, 'second(GM actor_consequence, same approval) ->', second.success, second.code, second.receipt?.authorization);
    note('PA2 pools before/after', before, pools(), 'receipts for approval', actors.ledger(room).receipts.filter(r => r.authorization?.proposalId === approved.approvalId).length);
  });

  it('PB: same approval bytes after the consuming receipt leaves the bounded ledger', async() => {
    await sync(null, { domain: 'elementalSpheres', value: spheres(['arcane', 'arcane', 'ember']) });
    const approved = approval();
    const registered = await ack(owner, 'actor_spell_approve', approved);
    const accepted = await ack(gm, 'actor_consequence', await gmCommand(approved, registered.contentHash));
    assert.equal(accepted.success, true, JSON.stringify(accepted));
    note('PB accepted commitSequence', accepted.receipt.commitSequence, 'pools', pools());
    // ordinary later room play: 270 GM manual creature changes, with the writer confirming checkpoints
    for (let i = 0; i < 270; i++) {
      const foe = actors.locate(room, foeRef).token;
      const r = await ack(gm, 'actor_consequence', await command(gm, [{ ref: foeRef, expectedRevision: revision(foeRef), finalResources: { hp: { current: foe.state.currentHp === 200 ? 199 : 200, temp: 0 } } }]));
      if (!r.success) {note('PB filler refused at', i, r.code); await new Promise(res => setTimeout(res, 50)); i--; continue;}
      if (i % 20 === 0) {await new Promise(res => setTimeout(res, 30));}
    }
    const state = actors.ledger(room);
    note('PB ledger replayFloor', state.replayFloor, 'receipts', state.receipts.length, 'consumed receipt still retained?', !!payments.consumedReceipt(room, approved.approvalId));
    // (1) owner checks the retained approval (e.g. after missing the acceptance broadcast)
    const check1 = await ack(owner, 'actor_spell_approve', approved);
    note('PB check same approval (home now after-state) ->', check1);
    // (2) the owner sheet later holds the same sphere list again and publishes it (owner sync), then checks
    note('PB owner sync back ->', (await sync({ domain: 'elementalSpheres', value: spheres(['ember']) }, { domain: 'elementalSpheres', value: spheres(['arcane', 'arcane', 'ember']) })).code);
    const check2 = await ack(owner, 'actor_spell_approve', approved);
    note('PB check same approval again ->', check2);
    if (check2.code === 'awaiting_gm') {
      const before = pools();
      const again = await ack(gm, 'actor_consequence', await gmCommand(approved, check2.contentHash));
      note('PB GM accepts the re-registered approval ->', again.success, again.code, 'pools', before, '->', pools(),
        'receipts for this approvalId', actors.ledger(room).receipts.filter(r => r.authorization?.proposalId === approved.approvalId).length);
    }
  });

  it('PC: privacy of Martyr ledger and Minstrel notes across all deliveries', async() => {
    const ledger = { type: 'devotionGauge', current: 2, max: 6, damage: 62, earnedLevels: 4, spentLevels: 2, bonusLevels: 0 };
    // pc is Arcanoneer in the fixture; the server is class-agnostic, so a devotion home is installable by the owner (owner sync parity)
    assert.equal((await sync(null, { domain: 'devotionGauge', value: ledger })).success, true);
    const after = { ...ledger, current: 3, spentLevels: 1 };
    const approved = approval({ target: pcRef, spell: { definitionId: 'martyr_restorative_prayer', definitionHash: `p9-spell:v1/${sha('prayer')}`, name: 'Restorative Prayer', kind: 'healing', damageTypes: [] },
      roll: { mode: 'digital', dice: [{ sides: 4, faces: [3] }], constant: 14, total: 17, reading: '1d4 + spirit' }, price: { ap: 1, mana: 5 },
      classPayment: { domain: 'devotionGauge', before: ledger, after, price: { cost: 0, gain: 1, required: 0 } } });
    const registered = await ack(owner, 'actor_spell_approve', approved);
    assert.equal(registered.code, 'awaiting_gm', JSON.stringify(registered));
    const c = actors.locate(room, pcRef).token.character;
    const chosen = JSON.stringify({ capability: 'p9-spell:v1', approvalId: approved.approvalId, roll: approved.roll, kind: 'healing', damageTypes: [], gmConfirmed: true });
    const accepted = await ack(gm, 'actor_consequence', await command(gm, [{ ref: pcRef, expectedRevision: revision(pcRef),
      finalResources: { ap: tempFirst(c.actionPoints.current, c.tempActionPoints, 1), mana: tempFirst(c.mana.current, c.tempMana, 5), hp: { current: 37, temp: 0 } }, classPayment: { mode: 'spell', domain: 'devotionGauge', approvalHash: registered.contentHash } }],
    { source: pcRef, target: pcRef, approval: { approvalId: approved.approvalId, contentHash: registered.contentHash },
      adjudication: { definitionId: 'martyr_restorative_prayer', definitionVersionOrHash: approved.spell.definitionHash, chosenResult: chosen, finalAmount: 17, adjustmentReason: '' } }));
    assert.equal(accepted.success, true, JSON.stringify(accepted));
    // A late joiner gets the room projection
    const lateUid = server.nextUserId(); server.registerAuthToken('late', lateUid);
    const late = server.connect({ token: 'late' }); clients.push(late); await once(late, 'connect');
    const lateSeen = []; late.onAny((event, payload) => lateSeen.push({ event, payload }));
    const joined = once(late, 'room_joined'); late.emit('join_room', { roomId: room.id, playerName: 'Late', password: '' }); const joinPayload = await joined;
    lateSeen.push({ event: 'room_joined', payload: joinPayload });
    await new Promise(res => setTimeout(res, 200));
    const otherCheckpoint = await ack(other, 'request_room_checkpoint', { roomId: room.id });
    const leak = list => list.filter(({ payload }) => /spentLevels|earnedLevels|bonusLevels|"damage":62/.test(JSON.stringify(payload ?? null))).map(({ event }) => event);
    note('PC leaks to GM events', leak(seen.gm), 'to other', leak(seen.other), 'to late joiner', leak(lateSeen), 'other checkpoint', leak([{ event: 'checkpoint', payload: otherCheckpoint }]));
    note('PC owner events with ledger', leak(seen.owner));
    // Minstrel notes via gmProjection
    const notes = { type: 'musicalNotes', notes: [2, 0, 1, 0, 0, 0, 0] };
    const proj = payments.gmProjection({ approval: { ...approved, classPayment: { domain: 'musicalNotes', before: notes, after: { type: 'musicalNotes', notes: [0, 0, 1, 0, 0, 0, 0] }, price: { costs: ['I', 'I'], gains: [] } } } });
    note('PC gmProjection minstrel classPayment', proj.classPayment);
  });

  it('PD: GM cannot install a class home; third party cannot approve for owner; temp-first enforced', async() => {
    note('PD GM sync for owner ->', (await ack(gm, 'actor_consequence', await command(gm, [{ ref: pcRef, expectedRevision: revision(pcRef), classPayment: { mode: 'sync', before: null, after: { domain: 'elementalSpheres', value: spheres(Array(12).fill('arcane')) } } }]))).code);
    note('PD other sync for owner ->', (await ack(other, 'actor_consequence', await command(other, [{ ref: pcRef, expectedRevision: revision(pcRef), classPayment: { mode: 'sync', before: null, after: { domain: 'elementalSpheres', value: spheres([]) } } }]))).code);
    // GM-proposed spell entry with no approval
    await sync(null, { domain: 'elementalSpheres', value: spheres(['arcane', 'arcane', 'ember']) });
    const approved = approval();
    const registered = await ack(owner, 'actor_spell_approve', approved);
    // ordinary-first payment instead of temp-first
    const c = actors.locate(room, pcRef).token.character, foe = actors.locate(room, foeRef).token;
    const cmd = await gmCommand(approved, registered.contentHash);
    const wrong = JSON.parse(JSON.stringify(cmd)); wrong.commandId = crypto.randomUUID();
    wrong.actors[0].finalResources.mana = { current: c.mana.current - 4, temp: c.tempMana };
    note('PD ordinary-first mana ->', (await ack(gm, 'actor_consequence', wrong)).code);
    // GM swaps the approved after for another class value via the spell entry: impossible since entry carries only hash/domain
    const tampered = JSON.parse(JSON.stringify(cmd)); tampered.commandId = crypto.randomUUID();
    tampered.actors[0].classPayment = { mode: 'sync', before: { domain: 'elementalSpheres', value: spheres(['arcane', 'arcane', 'ember']) }, after: { domain: 'elementalSpheres', value: spheres(Array(12).fill('wyrd')) } };
    note('PD GM sync entry inside approved command ->', (await ack(gm, 'actor_consequence', tampered)).code);
    // Extra actor slipped in (third party) is impossible (P7 bound 2) and self-target mismatch
    const healSelf = JSON.parse(JSON.stringify(cmd)); healSelf.commandId = crypto.randomUUID(); healSelf.actors = [healSelf.actors[0]];
    note('PD drop target entry ->', (await ack(gm, 'actor_consequence', healSelf)).code);
    note('PD unchanged home', actors.locate(room, pcRef).token.state.classPayment.value.spheres, 'foe hp', [foe.state.currentHp, foe.state.tempHealth]);
    // the original exact command still works
    const ok = await ack(gm, 'actor_consequence', cmd);
    note('PD exact command ->', ok.success, ok.code, 'pools', pools());
  });

  it('PE: owner approval replay after withdraw/decline is refused; approval after rebind/sheet change needs re-approval', async() => {
    await sync(null, { domain: 'elementalSpheres', value: spheres(['arcane', 'arcane', 'ember']) });
    const a = approval();
    const r = await ack(owner, 'actor_spell_approve', a);
    await ack(owner, 'actor_spell_withdraw', { roomId: room.id, approvalId: a.approvalId });
    note('PE replay withdrawn approval ->', (await ack(owner, 'actor_spell_approve', a)).code, 'GM bind withdrawn ->', (await ack(gm, 'actor_consequence', await gmCommand(a, r.contentHash))).code);
    // 300 closures push the withdrawn ID out of the bounded closed list
    for (let i = 0; i < 260; i++) {
      const x = approval();
      const rr = await ack(owner, 'actor_spell_approve', x);
      if (rr.code !== 'awaiting_gm') {note('PE filler', i, rr.code); break;}
      await ack(owner, 'actor_spell_withdraw', { roomId: room.id, approvalId: x.approvalId });
    }
    note('PE replay withdrawn approval after 260 later closures ->', (await ack(owner, 'actor_spell_approve', a)).code);
  });
});
after(() => require('fs').writeFileSync('/tmp/claude-0/p9/review/probes/server-probes.notes.txt', log.join('\n') + '\n'));
