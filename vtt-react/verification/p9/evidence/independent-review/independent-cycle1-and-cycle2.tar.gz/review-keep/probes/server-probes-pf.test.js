/** Independent reviewer scratch probes against the real registered stack (not production code). */
const S = '/home/claude/dj-github88/descension/server';
const assert = require('assert/strict');
const crypto = require('crypto');
const { createProductionStackServer } = require(`${S}/tests/helpers/productionStackServer`);
const { FirebaseBatchWriter } = require(`${S}/services/syncService`);
const actors = require(`${S}/services/actorConsequences`);
const payments = require(`${S}/services/spellPayments`);
const ack = (client, event, payload) => new Promise((resolve, reject) => {
  const timer = setTimeout(() => reject(new Error(`ack timeout: ${event}`)), 8000);
  client.emit(event, payload, result => {clearTimeout(timer); resolve(result);});
});
const once = (client, event) => new Promise(resolve => client.once(event, resolve));
const sha = value => crypto.createHash('sha256').update(value).digest('hex');
const DEF_HASH = `p9-spell:v1/${sha('arc_spark_bolt')}`;
const log = [];
const note = (...a) => {log.push(a.map(x => typeof x === 'string' ? x : JSON.stringify(x)).join(' ')); console.log('    PROBE', ...a.map(x => typeof x === 'string' ? x : JSON.stringify(x)));};

describe('Reviewer probes (registered production stack)', function() {
  this.timeout(120000);
  let server, writer, gm, owner, other, gmUid, ownerUid, otherUid, room, pcRef, foeRef, clients, epoch, seen;
  beforeEach(async() => {
    writer = new FirebaseBatchWriter(5, 50, { shouldPersist: () => true, persist: async() => ({ outcome: 'confirmed' }) });
    server = createProductionStackServer({ firebaseBatchWriter: writer });
    await server.start(); clients = []; seen = { gm: [], owner: [], other: [] };
    for (const event of ['actor_bind', 'actor_consequence', 'actor_snapshot', 'actor_spell_approve', 'actor_spell_withdraw', 'actor_spell_decline', 'actor_spell_list', 'actor_recovery', 'character_resource_updated', 'actor_propose', 'actor_adjudicate', 'join_room']) {
      server.setEventLimits(event, { maxPerMinute: 200000, maxPerSecond: 200000 });
    }
    gmUid = server.nextUserId(); ownerUid = server.nextUserId(); otherUid = server.nextUserId();
    server.registerAuthToken('gm', gmUid); server.registerAuthToken('owner', ownerUid); server.registerAuthToken('other', otherUid);
    gm = server.connect({ token: 'gm' }); clients.push(gm); await once(gm, 'connect');
    gm.onAny((event, payload) => seen.gm.push({ event, payload }));
    room = await server.seedRoom(gm.id, { gmUserId: gmUid, persistentRoomId: crypto.randomUUID() });
    for (const [token, name] of [['owner', 'Owner'], ['other', 'Other']]) {
      const client = server.connect({ token }); clients.push(client); await once(client, 'connect');
      client.onAny((event, payload) => seen[token].push({ event, payload }));
      const joined = once(client, 'room_joined'); client.emit('join_room', { roomId: room.id, playerName: name, password: '' }); await joined;
      if (token === 'owner') {owner = client;} else {other = client;}
    }
    server.players.get(owner.id).character = { id: 'ilse', class: 'Arcanoneer', classResource: { type: 'elementalSpheres', spheres: ['arcane', 'arcane', 'ember'], current: 3, max: 12 } };
    server.setCharacterOwner('ilse', ownerUid);
    const pc = { id: 'pc', ownerUserId: ownerUid, character: { id: 'ilse', name: 'Ilse', class: 'Arcanoneer', health: { current: 20, max: 40 }, mana: { current: 30, max: 30 },
      actionPoints: { current: 5, max: 5 }, tempHealth: 0, tempMana: 3, tempActionPoints: 1, classResource: { type: 'elementalSpheres', spheres: ['arcane', 'arcane', 'ember'] } }, state: { conditions: [] } };
    const foe = { id: 'foe', creatureId: 'grimmstalk', stats: { maxHp: 250, maxMana: 30, maxAP: 5 }, state: { currentHp: 200, tempHealth: 4, currentMana: 0, tempMana: 0, currentActionPoints: 2, tempActionPoints: 0, conditions: [] } };
    room.gameState.maps.default.characterTokens.pc = pc; room.gameState.maps.default.tokens.foe = foe;
    pcRef = (await ack(gm, 'actor_bind', { roomId: room.id, ref: { kind: 'character', roomId: room.id, mapId: 'default', tokenId: 'pc', ownerUid, characterId: 'ilse' }, snapshotHash: actors.hash(pc) })).ref;
    foeRef = (await ack(gm, 'actor_bind', { roomId: room.id, ref: { kind: 'creature', roomId: room.id, mapId: 'default', tokenId: 'foe' }, snapshotHash: actors.hash(foe) })).ref;
    epoch = (await ack(owner, 'actor_snapshot', { roomId: room.id })).actionEpoch;
  });
  afterEach(async() => {for (const client of clients) {client.disconnect();} await server.stop();});
  const snap = async client => ack(client, 'actor_snapshot', { roomId: room.id });
  const revision = ref => actors.locate(room, ref).contract.revision;
  const command = async(client, entries, extra = {}) => ({ version: 1, roomId: room.id, commandId: crypto.randomUUID(), actionEpoch: epoch,
    baseCommitSequence: (await snap(client)).commitSequence, actors: entries, ...extra });
  const spheres = list => ({ type: 'elementalSpheres', spheres: list });
  const sync = async(before, after) => ack(owner, 'actor_consequence', await command(owner, [{ ref: pcRef, expectedRevision: revision(pcRef), classPayment: { mode: 'sync', before, after } }]));
  const approval = (extra = {}) => ({ version: 1, roomId: room.id, approvalId: crypto.randomUUID(), actionEpoch: epoch, source: pcRef, target: foeRef,
    spell: { definitionId: 'arc_spark_bolt', definitionHash: DEF_HASH, name: 'Marrow-Piercing Slug', kind: 'damage', damageTypes: ['arcane'] },
    roll: { mode: 'physical', dice: [{ sides: 8, faces: [6] }], constant: 4, total: 10, reading: '1d8 + intelligence/4 → 1d8 + 4' },
    price: { ap: 1, mana: 4 },
    classPayment: { domain: 'elementalSpheres', before: spheres(['arcane', 'arcane', 'ember']), after: spheres(['ember']), price: { costs: ['arcane', 'arcane'], gains: [] } }, ...extra });
  const tempFirst = (current, temp, cost) => ({ current: current - Math.max(0, cost - temp), temp: Math.max(0, temp - cost) });
  const gmCommand = async(approved, contentHash, client = gm) => {
    const final = 7;
    const chosen = JSON.stringify({ capability: 'p9-spell:v1', approvalId: approved.approvalId, roll: approved.roll, kind: approved.spell.kind, damageTypes: approved.spell.damageTypes, gmConfirmed: true });
    const source = actors.locate(room, pcRef).token, foe = actors.locate(room, foeRef).token;
    return command(client, [
      { ref: pcRef, expectedRevision: revision(pcRef), finalResources: { ap: tempFirst(source.character.actionPoints.current, source.character.tempActionPoints, approved.price.ap),
        mana: tempFirst(source.character.mana.current, source.character.tempMana, approved.price.mana) },
      ...(approved.classPayment ? { classPayment: { mode: 'spell', domain: approved.classPayment.domain, approvalHash: contentHash } } : {}) },
      { ref: foeRef, expectedRevision: revision(foeRef), finalResources: { hp: { current: Math.max(0, foe.state.currentHp - Math.max(0, final - foe.state.tempHealth)), temp: Math.max(0, foe.state.tempHealth - final) } } }],
    { source: pcRef, target: foeRef, approval: { approvalId: approved.approvalId, contentHash },
      adjudication: { definitionId: 'arc_spark_bolt', definitionVersionOrHash: DEF_HASH, chosenResult: chosen, finalAmount: final, adjustmentReason: 'GM ruling' } });
  };
  const pools = () => { const c = actors.locate(room, pcRef).token.character; return { ap: [c.actionPoints.current, c.tempActionPoints], mana: [c.mana.current, c.tempMana] }; };

  it('PF: GM "check same command" for an accepted command after its receipt leaves the ledger', async() => {
    await sync(null, { domain: 'elementalSpheres', value: spheres(['arcane', 'arcane', 'ember']) });
    const approved = approval();
    const registered = await ack(owner, 'actor_spell_approve', approved);
    const cmd = await gmCommand(approved, registered.contentHash);
    const accepted = await ack(gm, 'actor_consequence', cmd);
    assert.equal(accepted.success, true);
    for (let i = 0; i < 270; i++) {
      const foe = actors.locate(room, foeRef).token;
      const r = await ack(gm, 'actor_consequence', await command(gm, [{ ref: foeRef, expectedRevision: revision(foeRef), finalResources: { hp: { current: foe.state.currentHp === 200 ? 199 : 200, temp: 0 } } }]));
      if (!r.success) {await new Promise(res => setTimeout(res, 50)); i--; continue;}
      if (i % 20 === 0) {await new Promise(res => setTimeout(res, 30));}
    }
    const retry = await ack(gm, 'actor_consequence', cmd);
    note('PF resend of the installed GM command ->', retry.code, '(client settleGm maps this to "Refused (...); nothing was applied.")');
  });
});
after(() => require('fs').writeFileSync('/tmp/claude-0/p9/review/probes/server-probes-pf.notes.txt', log.join('\n') + '\n'));
